import { useState } from "react";
import type { Screen } from "../types";

interface Props {
  onNavigate: (s: Screen) => void;
}

type SOSState = "idle" | "confirm" | "active" | "calling" | "offline";

const contacts = [
  { name: "Amma (Meena)", relation: "Mother", phone: "+91 98765 43210", notified: true },
  { name: "Ravi Bhai", relation: "Brother", phone: "+91 87654 32109", notified: true },
  { name: "Dr. Gupta", relation: "Doctor", phone: "+91 76543 21098", notified: false },
];

export default function SOS({ onNavigate }: Props) {
  const [state, setState] = useState<SOSState>("idle");
  const [countdown, setCountdown] = useState(5);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  const handleSOSPress = () => {
    setState("confirm");
    let c = 5;
    setCountdown(5);
    const t = setInterval(() => {
      c -= 1;
      setCountdown(c);
      if (c <= 0) {
        clearInterval(t);
        setState("active");
        let e = 0;
        const t2 = setInterval(() => {
          e += 1;
          setElapsedSeconds(e);
          if (e > 300) clearInterval(t2);
        }, 1000);
      }
    }, 1000);
  };

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2,"0")}:${String(s % 60).padStart(2,"0")}`;

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Header */}
      <header className={`flex items-center gap-3 px-4 py-3 border-b sticky top-0 z-20 transition-colors ${
        state === "active" || state === "calling" ? "bg-[#EF4444] border-[#DC2626]" : "bg-white border-[#E8E4F5]"
      }`}>
        <button
          onClick={() => { setState("idle"); onNavigate("home"); }}
          className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg transition-colors ${
            state === "active" ? "bg-white/20 text-white hover:bg-white/30" : "bg-[#FEE2E2] text-[#DC2626] hover:bg-[#FED7D7]"
          }`}
        >
          ←
        </button>
        <div className="flex-1">
          <div className={`font-display font-bold text-base ${state === "active" ? "text-white" : "text-[#1A1825]"}`}>
            SOS Emergency
          </div>
          <div className={`text-[10px] ${state === "active" ? "text-white/70" : "text-[#9CA3AF]"}`}>
            {state === "active" ? `Active · ${formatTime(elapsedSeconds)}` : "Phone-based safety feature"}
          </div>
        </div>
        {state === "active" && (
          <button
            onClick={() => setState("idle")}
            className="bg-white/20 text-white text-xs font-bold px-3 py-1.5 rounded-lg hover:bg-white/30 transition-colors"
          >
            Cancel SOS
          </button>
        )}
      </header>

      <div className="flex-1 overflow-y-auto scrollbar-hide pb-24 md:pb-6">

        {/* IDLE STATE */}
        {state === "idle" && (
          <div className="px-4 pt-6 space-y-6">
            {/* Big SOS button */}
            <div className="flex flex-col items-center py-6">
              <div className="text-center mb-6">
                <div className="font-display font-bold text-[#1A1825] text-xl mb-1">Emergency Alert</div>
                <div className="text-[#6B7280] text-sm">Tap the button to activate SOS and alert your contacts</div>
              </div>
              <button
                onClick={handleSOSPress}
                className="w-36 h-36 rounded-full bg-[#EF4444] flex flex-col items-center justify-center text-white shadow-2xl sos-pulse hover:bg-[#DC2626] transition-colors active:scale-95"
                style={{boxShadow: "0 0 0 0 rgba(239,68,68,0.4)"}}
              >
                <span className="text-4xl mb-1">🚨</span>
                <span className="font-display font-bold text-lg">SOS</span>
              </button>
              <div className="mt-4 text-[#9CA3AF] text-xs text-center">Hold for 3 seconds in real emergency</div>
            </div>

            {/* Volume button shortcut info */}
            <div className="bg-[#FEF3C7] border border-[#FDE68A] rounded-2xl p-4">
              <div className="flex items-start gap-3">
                <span className="text-2xl shrink-0">📱</span>
                <div>
                  <div className="font-display font-semibold text-[#92400E] text-sm mb-1">Volume Button SOS Shortcut</div>
                  <p className="text-xs text-[#78350F] leading-relaxed">
                    Press your phone's <strong>Volume Up button 5 times rapidly</strong> to trigger SOS — even with the screen off.
                  </p>
                  <div className="mt-2 bg-[#FDE68A]/50 rounded-lg px-3 py-2 text-[10px] text-[#92400E] font-medium">
                    ⚠️ This is a <strong>phone-based software shortcut</strong> — not external hardware, not the Power/Off button. Requires SpeakMySign to be running.
                  </div>
                </div>
              </div>
            </div>

            {/* Emergency contacts */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="font-display font-semibold text-[#1A1825]">Emergency Contacts</div>
                <button onClick={() => onNavigate("settings")} className="text-xs text-[#6C5CE7] font-semibold hover:underline">Edit</button>
              </div>
              <div className="space-y-2">
                {contacts.map((c, i) => (
                  <div key={i} className="bg-white rounded-xl border border-[#E8E4F5] p-3.5 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-[#FEE2E2] flex items-center justify-center text-lg shrink-0">👤</div>
                    <div className="flex-1">
                      <div className="font-semibold text-[#1A1825] text-sm">{c.name}</div>
                      <div className="text-xs text-[#9CA3AF]">{c.relation} · {c.phone}</div>
                    </div>
                    <div className="flex gap-1.5">
                      <span className="text-xs bg-[#FEE2E2] text-[#DC2626] px-2 py-1 rounded-lg font-medium">SOS</span>
                      <span className="text-xs bg-[#F0EEFF] text-[#6C5CE7] px-2 py-1 rounded-lg font-medium">SMS</span>
                    </div>
                  </div>
                ))}
                <button className="w-full border-2 border-dashed border-[#E8E4F5] rounded-xl py-3 text-sm text-[#9CA3AF] hover:border-[#6C5CE7] hover:text-[#6C5CE7] transition-colors">
                  + Add Emergency Contact
                </button>
              </div>
            </div>

            {/* SOS message preview */}
            <div>
              <div className="font-display font-semibold text-[#1A1825] mb-3">Auto-sent SOS Message</div>
              <div className="bg-white rounded-xl border border-[#E8E4F5] p-4">
                <div className="text-xs text-[#9CA3AF] mb-2">SMS preview — sent to all contacts:</div>
                <div className="bg-[#FEE2E2] rounded-lg p-3 text-xs text-[#7F1D1D] leading-relaxed font-medium">
                  🚨 EMERGENCY ALERT from Ananya (SpeakMySign)<br/>
                  I need immediate help. My location: [GPS Coordinates]<br/>
                  This is an automated SOS message. Please call or come to my location.
                </div>
                <button onClick={() => onNavigate("settings")} className="mt-2 text-xs text-[#6C5CE7] font-semibold hover:underline">
                  Customize message →
                </button>
              </div>
            </div>

            {/* Offline mode */}
            <div className="bg-[#F4F2FB] rounded-2xl p-4 flex items-start gap-3">
              <span className="text-2xl shrink-0">📡</span>
              <div>
                <div className="font-display font-semibold text-[#1A1825] text-sm mb-1">Works Offline Too</div>
                <div className="text-xs text-[#6B7280] leading-relaxed">SOS alert sends via SMS (no internet needed). Location is cached from last GPS fix. Alarm and vibration activate even in airplane mode.</div>
              </div>
            </div>
          </div>
        )}

        {/* CONFIRM STATE */}
        {state === "confirm" && (
          <div className="flex flex-col items-center justify-center min-h-full px-6 py-12 text-center fade-in">
            <div className="w-32 h-32 rounded-full bg-[#EF4444] flex items-center justify-center text-5xl mb-6 shadow-2xl" style={{animation:"sos-pulse 1s ease-in-out infinite"}}>
              🚨
            </div>
            <div className="font-display font-bold text-[#1A1825] text-2xl mb-2">Activating SOS…</div>
            <div className="text-[#6B7280] text-sm mb-6">
              Emergency alert will be sent in <span className="text-[#EF4444] font-bold text-xl">{countdown}</span> seconds
            </div>
            <div className="w-full bg-[#FEE2E2] rounded-full h-3 mb-8">
              <div className="bg-[#EF4444] h-3 rounded-full transition-all" style={{width:`${((5-countdown)/5)*100}%`}} />
            </div>
            <button
              onClick={() => setState("idle")}
              className="bg-white border-2 border-[#E8E4F5] text-[#1A1825] font-display font-bold px-8 py-4 rounded-xl text-lg hover:bg-[#F4F2FB] transition-colors"
            >
              Cancel
            </button>
          </div>
        )}

        {/* ACTIVE STATE */}
        {state === "active" && (
          <div className="bg-[#EF4444] min-h-full flex flex-col px-4 pt-6 pb-8 fade-in">
            {/* Alarm indicator */}
            <div className="flex items-center justify-center gap-3 mb-6">
              <div className="w-3 h-3 rounded-full bg-white animate-ping" />
              <div className="text-white font-display font-bold text-lg">SOS ACTIVE</div>
              <div className="w-3 h-3 rounded-full bg-white animate-ping" style={{animationDelay:"0.5s"}} />
            </div>

            <div className="text-center mb-8">
              <div className="font-display font-bold text-white text-5xl mb-2">{formatTime(elapsedSeconds)}</div>
              <div className="text-white/70 text-sm">Emergency active</div>
            </div>

            {/* Contacts notified */}
            <div className="bg-white/20 rounded-2xl p-4 mb-4">
              <div className="text-white font-display font-semibold text-sm mb-3">Contacts Notified</div>
              {contacts.map((c, i) => (
                <div key={i} className="flex items-center gap-3 py-2 border-b border-white/10 last:border-0">
                  <span className="text-lg">👤</span>
                  <div className="flex-1">
                    <div className="text-white font-medium text-sm">{c.name}</div>
                    <div className="text-white/60 text-xs">{c.phone}</div>
                  </div>
                  <span className="text-white/80 text-xs">📩 SMS sent</span>
                </div>
              ))}
            </div>

            {/* Call button */}
            <button
              onClick={() => setState("calling")}
              className="w-full bg-white text-[#EF4444] font-display font-bold py-4 rounded-2xl text-lg mb-3 flex items-center justify-center gap-3 hover:bg-[#FEF2F2] transition-colors shadow-lg"
            >
              📞 Call Emergency Services
            </button>

            <button
              onClick={() => setState("idle")}
              className="w-full bg-white/20 text-white font-display font-bold py-3.5 rounded-2xl text-base hover:bg-white/30 transition-colors"
            >
              Cancel SOS — I'm Safe
            </button>

            <div className="mt-4 text-center text-white/50 text-xs">
              Alarm sound & vibration active · Location being shared
            </div>
          </div>
        )}

        {/* CALLING STATE */}
        {state === "calling" && (
          <div className="bg-[#1A1825] min-h-full flex flex-col items-center justify-center px-6 py-12 text-center fade-in">
            <div className="text-6xl mb-6 animate-bounce">📞</div>
            <div className="font-display font-bold text-white text-2xl mb-2">Calling 112</div>
            <div className="text-white/50 text-sm mb-2">Emergency Services</div>
            <div className="flex items-center gap-1 mb-8">
              {[1,2,3,4,5].map((i) => <div key={i} className="w-1.5 bg-[#EF4444] rounded-full wave-bar" style={{height:`${8+i*3}px`}} />)}
            </div>
            <div className="bg-white/10 rounded-2xl p-4 mb-8 text-left w-full max-w-sm">
              <div className="text-xs text-white/50 mb-1">Location shared:</div>
              <div className="text-white font-medium text-sm">📍 Connaught Place, New Delhi · 28.6315°N, 77.2167°E</div>
            </div>
            <button
              onClick={() => setState("active")}
              className="w-full bg-[#EF4444] text-white font-display font-bold py-4 rounded-2xl text-base hover:bg-[#DC2626] transition-colors"
            >
              End Call
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
