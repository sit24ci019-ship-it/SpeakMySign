import { useState } from "react";
import type { Screen } from "../types";

interface Props {
  onNavigate: (s: Screen) => void;
}

type MsgRole = "tutor" | "user";
interface TutorMsg { id: number; role: MsgRole; text: string; sign?: string; feedback?: string; }

const initialMsgs: TutorMsg[] = [
  { id: 1, role: "tutor", text: "Namaste! I'm Aasha, your AI ISL tutor 🤟 I'm here to help you learn Indian Sign Language step by step. What would you like to practice today?" },
  { id: 2, role: "user", text: "I want to learn how to sign greetings" },
  { id: 3, role: "tutor", text: "Great choice! Greetings are the foundation of any language. Let's start with NAMASTE — the most universal Indian greeting.", sign: "NAMASTE", feedback: "Position both palms together at chest height, fingers pointing up. This is identical to the prayer gesture you may already know!" },
  { id: 4, role: "user", text: "How do I sign 'how are you'?" },
  { id: 5, role: "tutor", text: "Excellent question! In ISL, 'How are you?' is expressed as a two-part sign. First sign 'AAP' (You), then 'KAISA/KAISI' (How/How are you feeling).", sign: "KAISA HAIN AAP?", feedback: "Tip: ISL follows Subject-Object-Verb order, which differs from spoken Hindi and English." },
];

const suggestions = [
  "Teach me emergency signs",
  "Practice numbers 1–10",
  "Family vocabulary",
  "Signs for emotions",
  "Fingerspelling basics",
];

export default function AITutor({ onNavigate }: Props) {
  const [messages, setMessages] = useState<TutorMsg[]>(initialMsgs);
  const [input, setInput] = useState("");

  const send = (text: string) => {
    if (!text.trim()) return;
    const userMsg: TutorMsg = { id: Date.now(), role: "user", text };
    const tutorReply: TutorMsg = {
      id: Date.now() + 1, role: "tutor",
      text: `Great question about "${text}"! Let me demonstrate the ISL sign for this. In ISL, this concept is expressed with a specific handshape and motion. Practice it in front of a mirror for best results.`,
      sign: text.toUpperCase().split(" ")[0],
      feedback: "Keep your wrist relaxed. The movement should be fluid, not jerky. Try it 5 times slowly."
    };
    setMessages(prev => [...prev, userMsg, tutorReply]);
    setInput("");
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5]">
        <button onClick={() => onNavigate("home")} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors">←</button>
        <div className="flex items-center gap-3 flex-1">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#6C5CE7] to-[#8B7CF8] flex items-center justify-center text-white text-lg">🤖</div>
          <div>
            <div className="font-display font-semibold text-[#1A1825] text-sm">Aasha — AI ISL Tutor</div>
            <div className="text-[10px] text-[#10B981] flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-[#10B981] inline-block" />Online</div>
          </div>
        </div>
        <button className="bg-[#F0EEFF] text-[#6C5CE7] text-xs font-bold px-3 py-1.5 rounded-lg">Progress</button>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto scrollbar-hide px-4 py-4 space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} gap-3`}>
            {msg.role === "tutor" && (
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#6C5CE7] to-[#8B7CF8] flex items-center justify-center text-white text-sm shrink-0 mt-1">🤖</div>
            )}
            <div className={`max-w-[80%] space-y-2`}>
              <div className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                msg.role === "user"
                  ? "bg-[#6C5CE7] text-white rounded-br-sm"
                  : "bg-white border border-[#E8E4F5] text-[#1A1825] rounded-bl-sm"
              }`}>
                {msg.text}
              </div>
              {msg.sign && (
                <div className="bg-[#F0EEFF] border border-[#D8D0FF] rounded-xl p-3">
                  <div className="text-center mb-2">
                    <div className="text-4xl mb-1">🤟</div>
                    <div className="font-display font-bold text-[#6C5CE7] text-sm">{msg.sign}</div>
                  </div>
                  {msg.feedback && (
                    <div className="bg-white rounded-lg p-2.5 text-xs text-[#4A4560] leading-relaxed border border-[#E8E4F5]">
                      💡 {msg.feedback}
                    </div>
                  )}
                  <button className="w-full mt-2 bg-[#6C5CE7] text-white text-xs font-bold py-2 rounded-lg hover:bg-[#5A4BD1] transition-colors">
                    Practice with Camera
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Suggestions */}
      <div className="px-4 pb-2 flex gap-2 overflow-x-auto scrollbar-hide">
        {suggestions.map((s) => (
          <button key={s} onClick={() => send(s)} className="shrink-0 text-xs bg-[#F0EEFF] text-[#6C5CE7] px-3 py-1.5 rounded-full font-medium hover:bg-[#E8E2FF] transition-colors border border-[#D8D0FF]">
            {s}
          </button>
        ))}
      </div>

      {/* Input */}
      <div className="px-4 pb-4 pt-2 bg-white border-t border-[#E8E4F5]">
        <div className="flex items-center gap-2">
          <div className="flex-1 bg-[#F4F2FB] rounded-xl px-4 py-2.5 flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send(input)}
              placeholder="Ask Aasha anything about ISL…"
              className="flex-1 text-sm bg-transparent outline-none text-[#1A1825] placeholder:text-[#9CA3AF]"
            />
          </div>
          <button onClick={() => send(input)} disabled={!input.trim()} className="w-10 h-10 rounded-xl bg-[#6C5CE7] text-white flex items-center justify-center disabled:opacity-40 hover:bg-[#5A4BD1] transition-colors">→</button>
        </div>
      </div>
    </div>
  );
}
