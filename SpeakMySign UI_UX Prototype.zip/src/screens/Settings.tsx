import { useState } from "react";
import type { Screen } from "../types";

interface Props {
  onNavigate: (s: Screen) => void;
}

type Section = "main" | "language" | "speech" | "accessibility" | "camera" | "privacy" | "notifications" | "sos";

interface Toggle { label: string; desc?: string; key: string; }

const settingSections = [
  { id: "language", icon: "🌐", label: "Language & ISL Dialect", desc: "Standard ISL, regional variants" },
  { id: "speech", icon: "🔊", label: "Speech & Voice", desc: "TTS voice, speed, language" },
  { id: "accessibility", icon: "♿", label: "Accessibility", desc: "Text size, contrast, haptics" },
  { id: "camera", icon: "📷", label: "Camera & Microphone", desc: "Permissions, sensitivity" },
  { id: "privacy", icon: "🔒", label: "Privacy & Data", desc: "History, sharing, deletion" },
  { id: "notifications", icon: "🔔", label: "Notifications", desc: "Reminders, community alerts" },
  { id: "sos", icon: "🚨", label: "SOS Preferences", desc: "Contacts, shortcuts, message" },
];

const languageOptions = {
  isl: ["Standard ISL (National)", "Mumbai Regional", "Delhi Regional", "Chennai Regional", "Kolkata Regional"],
  speech: ["Hindi", "English", "Tamil", "Telugu", "Kannada", "Bengali"],
};

const accessibilityToggles: Toggle[] = [
  { label: "Large Text Mode", desc: "Increases all text by 20%", key: "largeText" },
  { label: "High Contrast Mode", desc: "Enhanced colors for readability", key: "highContrast" },
  { label: "Haptic Feedback", desc: "Vibrate on key interactions", key: "haptics" },
  { label: "Reduce Motion", desc: "Minimize animations", key: "reduceMotion" },
  { label: "Screen Reader Support", desc: "Optimized for VoiceOver/TalkBack", key: "screenReader" },
];

const sosToggles: Toggle[] = [
  { label: "Volume Button Shortcut", desc: "Press Volume Up 5× to trigger SOS", key: "volShortcut" },
  { label: "Auto-send SMS", desc: "Message contacts immediately on SOS", key: "autoSMS" },
  { label: "Share GPS Location", desc: "Include live location in SOS alert", key: "gpsShare" },
  { label: "Alarm Sound", desc: "Loud alarm when SOS activates", key: "alarm" },
  { label: "Vibration Alert", desc: "Strong vibration pattern on SOS", key: "vibration" },
  { label: "Offline Mode", desc: "SOS works without internet via SMS", key: "offline" },
];

const notifToggles: Toggle[] = [
  { label: "Daily Practice Reminder", desc: "9:00 AM every day", key: "dailyReminder" },
  { label: "Forum Replies", desc: "When someone replies to your post", key: "forumReplies" },
  { label: "New Messages", desc: "Chat notifications", key: "messages" },
  { label: "New ISL Dictionary Entries", desc: "Weekly digest", key: "dictUpdates" },
  { label: "Events Nearby", desc: "ISL workshops and meetups", key: "events" },
];

export default function Settings({ onNavigate }: Props) {
  const [section, setSection] = useState<Section>("main");
  const [toggles, setToggles] = useState<Record<string, boolean>>({
    largeText: true, highContrast: true, haptics: true, reduceMotion: false, screenReader: false,
    volShortcut: true, autoSMS: true, gpsShare: true, alarm: true, vibration: true, offline: true,
    dailyReminder: true, forumReplies: true, messages: true, dictUpdates: false, events: true,
  });
  const [islDialect, setIslDialect] = useState(languageOptions.isl[0]);
  const [speechLang, setSpeechLang] = useState("Hindi");
  const [speechRate, setSpeechRate] = useState(1.0);
  const [sosMessage, setSosMessage] = useState("🚨 EMERGENCY ALERT from Ananya (SpeakMySign)\nI need immediate help. My location: [GPS]\nThis is an automated SOS message.");

  const toggle = (key: string) => setToggles(prev => ({...prev, [key]: !prev[key]}));

  const Toggle = ({ label, desc, k }: {label: string; desc?: string; k: string}) => (
    <div className="flex items-center justify-between py-3.5 border-b border-[#F4F2FB] last:border-0">
      <div className="flex-1 pr-4">
        <div className="text-sm font-medium text-[#1A1825]">{label}</div>
        {desc && <div className="text-xs text-[#9CA3AF] mt-0.5">{desc}</div>}
      </div>
      <button
        onClick={() => toggle(k)}
        className={`relative w-12 h-6 rounded-full transition-colors shrink-0 ${toggles[k] ? "bg-[#6C5CE7]" : "bg-[#D1D5DB]"}`}
      >
        <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${toggles[k] ? "translate-x-6" : "translate-x-0.5"}`} />
      </button>
    </div>
  );

  const BackHeader = ({ title, sub }: { title: string; sub?: string }) => (
    <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5] sticky top-0 z-20">
      <button onClick={() => setSection("main")} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors">←</button>
      <div>
        <div className="font-display font-bold text-[#1A1825] text-base">{title}</div>
        {sub && <div className="text-[10px] text-[#9CA3AF]">{sub}</div>}
      </div>
    </header>
  );

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {section === "main" && (
        <>
          <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5]">
            <button onClick={() => onNavigate("profile")} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors">←</button>
            <div className="flex-1"><div className="font-display font-bold text-[#1A1825] text-base">Settings</div></div>
          </header>
          <div className="flex-1 overflow-y-auto scrollbar-hide pb-24 md:pb-6">
            {/* Profile mini */}
            <div className="px-4 py-4 bg-[#F8F6FF] border-b border-[#E8E4F5] flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-[#6C5CE7] flex items-center justify-center text-white font-bold font-display">AN</div>
              <div>
                <div className="font-display font-semibold text-[#1A1825]">Ananya Nair</div>
                <div className="text-xs text-[#9CA3AF]">ananya.nair@email.com</div>
              </div>
              <button onClick={() => onNavigate("profile")} className="ml-auto text-xs text-[#6C5CE7] font-semibold hover:underline">Edit →</button>
            </div>

            <div className="px-4 pt-4 space-y-1">
              {settingSections.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSection(s.id as Section)}
                  className="w-full flex items-center gap-4 bg-white rounded-xl border border-[#E8E4F5] px-4 py-3.5 hover:border-[#6C5CE7]/40 hover:bg-[#FAFAF8] transition-all text-left"
                >
                  <span className="text-xl w-7 text-center">{s.icon}</span>
                  <div className="flex-1">
                    <div className="font-medium text-[#1A1825] text-sm">{s.label}</div>
                    <div className="text-xs text-[#9CA3AF]">{s.desc}</div>
                  </div>
                  <div className="text-[#9CA3AF]">›</div>
                </button>
              ))}
            </div>

            <div className="px-4 pt-6 pb-4 space-y-2">
              <button className="w-full text-sm text-[#9CA3AF] py-3 hover:text-[#6B7280] transition-colors">Privacy Policy</button>
              <button className="w-full text-sm text-[#9CA3AF] py-3 hover:text-[#6B7280] transition-colors">Terms of Service</button>
              <button className="w-full text-sm text-[#EF4444] py-3 font-semibold hover:text-[#DC2626] transition-colors">Sign Out</button>
            </div>
          </div>
        </>
      )}

      {section === "language" && (
        <><BackHeader title="Language & ISL Dialect" sub="Communication preferences" />
        <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pt-5 pb-8 space-y-5">
          <div className="bg-white rounded-2xl border border-[#E8E4F5] p-4">
            <div className="font-display font-semibold text-[#1A1825] mb-3">ISL Dialect</div>
            {languageOptions.isl.map((d) => (
              <button key={d} onClick={() => setIslDialect(d)} className="w-full flex items-center justify-between py-3 border-b border-[#F4F2FB] last:border-0">
                <span className="text-sm text-[#1A1825]">{d}</span>
                {islDialect === d && <span className="text-[#6C5CE7]">✓</span>}
              </button>
            ))}
          </div>
          <div className="bg-white rounded-2xl border border-[#E8E4F5] p-4">
            <div className="font-display font-semibold text-[#1A1825] mb-3">App Display Language</div>
            {["English", "Hindi", "Tamil", "Telugu"].map((l) => (
              <button key={l} className="w-full flex items-center justify-between py-3 border-b border-[#F4F2FB] last:border-0">
                <span className="text-sm text-[#1A1825]">{l}</span>
                {l === "English" && <span className="text-[#6C5CE7]">✓</span>}
              </button>
            ))}
          </div>
        </div></>
      )}

      {section === "speech" && (
        <><BackHeader title="Speech & Voice" sub="Text-to-speech settings" />
        <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pt-5 pb-8 space-y-5">
          <div className="bg-white rounded-2xl border border-[#E8E4F5] p-4">
            <div className="font-display font-semibold text-[#1A1825] mb-3">Speech Language</div>
            {languageOptions.speech.map((l) => (
              <button key={l} onClick={() => setSpeechLang(l)} className="w-full flex items-center justify-between py-3 border-b border-[#F4F2FB] last:border-0">
                <span className="text-sm text-[#1A1825]">{l}</span>
                {speechLang === l && <span className="text-[#6C5CE7]">✓</span>}
              </button>
            ))}
          </div>
          <div className="bg-white rounded-2xl border border-[#E8E4F5] p-4">
            <div className="font-display font-semibold text-[#1A1825] mb-1">Speech Rate</div>
            <div className="text-sm text-[#9CA3AF] mb-3">{speechRate}× speed</div>
            <input type="range" min="0.5" max="2" step="0.1" value={speechRate} onChange={(e) => setSpeechRate(parseFloat(e.target.value))} className="w-full accent-[#6C5CE7]" />
            <div className="flex justify-between text-xs text-[#9CA3AF] mt-1"><span>Slow</span><span>Normal</span><span>Fast</span></div>
          </div>
        </div></>
      )}

      {section === "accessibility" && (
        <><BackHeader title="Accessibility" sub="Visual and interaction preferences" />
        <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pt-5 pb-8">
          <div className="bg-white rounded-2xl border border-[#E8E4F5] px-4">
            {accessibilityToggles.map((t) => <Toggle key={t.key} label={t.label} desc={t.desc} k={t.key} />)}
          </div>
        </div></>
      )}

      {section === "notifications" && (
        <><BackHeader title="Notifications" sub="Alerts and reminders" />
        <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pt-5 pb-8">
          <div className="bg-white rounded-2xl border border-[#E8E4F5] px-4">
            {notifToggles.map((t) => <Toggle key={t.key} label={t.label} desc={t.desc} k={t.key} />)}
          </div>
        </div></>
      )}

      {section === "sos" && (
        <><BackHeader title="SOS Preferences" sub="Emergency configuration" />
        <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pt-5 pb-8 space-y-5">
          <div className="bg-[#FEF2F2] border border-[#FECACA] rounded-2xl p-4">
            <div className="font-display font-semibold text-[#DC2626] mb-1">📱 Volume Button Shortcut</div>
            <p className="text-xs text-[#7F1D1D] leading-relaxed">Press Volume Up 5 times rapidly to trigger SOS. This is a <strong>phone software feature</strong> — not the Power button and not external hardware. Requires the app to be running in background.</p>
          </div>
          <div className="bg-white rounded-2xl border border-[#E8E4F5] px-4">
            {sosToggles.map((t) => <Toggle key={t.key} label={t.label} desc={t.desc} k={t.key} />)}
          </div>
          <div className="bg-white rounded-2xl border border-[#E8E4F5] p-4">
            <div className="font-display font-semibold text-[#1A1825] mb-2">SOS Message Text</div>
            <textarea rows={4} value={sosMessage} onChange={(e) => setSosMessage(e.target.value)} className="w-full bg-[#F4F2FB] rounded-xl p-3 text-xs text-[#1A1825] outline-none focus:ring-2 focus:ring-[#6C5CE7]/30 resize-none leading-relaxed" />
            <div className="text-[10px] text-[#9CA3AF] mt-1">[GPS] is replaced with your live location when SOS activates.</div>
          </div>
          <button onClick={() => onNavigate("sos")} className="w-full bg-[#EF4444] text-white font-display font-bold py-4 rounded-xl text-sm hover:bg-[#DC2626] transition-colors">
            🚨 Go to SOS Screen
          </button>
        </div></>
      )}

      {(section === "camera" || section === "privacy") && (
        <><BackHeader title={section === "camera" ? "Camera & Microphone" : "Privacy & Data"} />
        <div className="flex-1 flex items-center justify-center text-center px-6">
          <div>
            <div className="text-4xl mb-3">{section === "camera" ? "📷" : "🔒"}</div>
            <div className="font-display font-semibold text-[#1A1825] mb-1">{section === "camera" ? "Camera Settings" : "Privacy Controls"}</div>
            <div className="text-sm text-[#9CA3AF]">Manage {section === "camera" ? "camera and microphone permissions in your device settings" : "your data, history, and sharing preferences"}</div>
          </div>
        </div></>
      )}
    </div>
  );
}
