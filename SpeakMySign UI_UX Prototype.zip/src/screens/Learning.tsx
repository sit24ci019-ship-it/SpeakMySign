import { useState } from "react";
import type { Screen } from "../types";

interface Props {
  onNavigate: (s: Screen) => void;
}

/* ─── Data ─────────────────────────────────────────────────── */

const STREAK = 7;
const XP = 1240;
const LEVEL = 12;
const XP_TO_NEXT = 1500;
const DAILY_GOAL_XP = 50;
const DAILY_EARNED_XP = 30;

const achievements = [
  { id: "first-sign", emoji: "🤟", label: "First Sign", desc: "Completed your first ISL sign", earned: true },
  { id: "week-streak", emoji: "🔥", label: "Week Warrior", desc: "7-day practice streak", earned: true },
  { id: "level10", emoji: "⭐", label: "Level 10", desc: "Reached Level 10", earned: true },
  { id: "alphabet-master", emoji: "🔤", label: "Alphabet Master", desc: "Mastered all ISL alphabets", earned: true },
  { id: "scholar", emoji: "🎓", label: "Scholar", desc: "Complete 5 modules", earned: false },
  { id: "diamond", emoji: "💎", label: "Diamond", desc: "30-day streak", earned: false },
  { id: "speed-signer", emoji: "⚡", label: "Speed Signer", desc: "Score 100% in a timed quiz", earned: false },
  { id: "social", emoji: "🤝", label: "Community Star", desc: "Share 10 forum posts", earned: false },
];

interface Lesson {
  id: number;
  title: string;
  type: "lesson" | "practice" | "quiz" | "checkpoint";
  xp: number;
  status: "done" | "active" | "locked";
  stars?: number;
}

interface Unit {
  id: number;
  title: string;
  subtitle: string;
  emoji: string;
  color: string;
  lessons: Lesson[];
}

const units: Unit[] = [
  {
    id: 1, title: "Unit 1", subtitle: "ISL Foundations",
    emoji: "🌱", color: "#6C5CE7",
    lessons: [
      { id: 101, title: "Handshapes & Basics", type: "lesson", xp: 10, status: "done", stars: 3 },
      { id: 102, title: "Vowels: A E I O U", type: "practice", xp: 10, status: "done", stars: 3 },
      { id: 103, title: "Consonants B–F", type: "lesson", xp: 10, status: "done", stars: 2 },
      { id: 104, title: "Consonants G–L", type: "practice", xp: 10, status: "done", stars: 3 },
      { id: 105, title: "Consonants M–R", type: "lesson", xp: 10, status: "done", stars: 1 },
      { id: 106, title: "Consonants S–Z", type: "practice", xp: 10, status: "done", stars: 3 },
      { id: 107, title: "Alphabet Review", type: "quiz", xp: 20, status: "done", stars: 3 },
      { id: 108, title: "Unit 1 Checkpoint", type: "checkpoint", xp: 30, status: "done", stars: 3 },
    ],
  },
  {
    id: 2, title: "Unit 2", subtitle: "Greetings & People",
    emoji: "👋", color: "#00C9A7",
    lessons: [
      { id: 201, title: "Hello & Goodbye", type: "lesson", xp: 10, status: "done", stars: 3 },
      { id: 202, title: "How Are You?", type: "practice", xp: 10, status: "done", stars: 2 },
      { id: 203, title: "Names & Introduction", type: "lesson", xp: 10, status: "active" },
      { id: 204, title: "Please & Thank You", type: "practice", xp: 10, status: "locked" },
      { id: 205, title: "Sorry & Excuse Me", type: "lesson", xp: 10, status: "locked" },
      { id: 206, title: "Greetings Quiz", type: "quiz", xp: 20, status: "locked" },
      { id: 207, title: "Unit 2 Checkpoint", type: "checkpoint", xp: 30, status: "locked" },
    ],
  },
  {
    id: 3, title: "Unit 3", subtitle: "Numbers & Time",
    emoji: "🔢", color: "#FF7043",
    lessons: [
      { id: 301, title: "Numbers 1–10", type: "lesson", xp: 10, status: "locked" },
      { id: 302, title: "Numbers 11–100", type: "practice", xp: 10, status: "locked" },
      { id: 303, title: "Days of the Week", type: "lesson", xp: 10, status: "locked" },
      { id: 304, title: "Months & Seasons", type: "practice", xp: 10, status: "locked" },
      { id: 305, title: "Telling Time", type: "lesson", xp: 10, status: "locked" },
      { id: 306, title: "Numbers & Time Quiz", type: "quiz", xp: 20, status: "locked" },
    ],
  },
  {
    id: 4, title: "Unit 4", subtitle: "Family & Relationships",
    emoji: "👨‍👩‍👧", color: "#F59E0B",
    lessons: [
      { id: 401, title: "Mother & Father", type: "lesson", xp: 10, status: "locked" },
      { id: 402, title: "Siblings & Family", type: "practice", xp: 10, status: "locked" },
      { id: 403, title: "Friends & Colleagues", type: "lesson", xp: 10, status: "locked" },
      { id: 404, title: "Family Quiz", type: "quiz", xp: 20, status: "locked" },
    ],
  },
  {
    id: 5, title: "Unit 5", subtitle: "Everyday Life",
    emoji: "🏠", color: "#EC4899",
    lessons: [
      { id: 501, title: "Food & Drink", type: "lesson", xp: 10, status: "locked" },
      { id: 502, title: "Colours & Shapes", type: "practice", xp: 10, status: "locked" },
      { id: 503, title: "Weather & Nature", type: "lesson", xp: 10, status: "locked" },
      { id: 504, title: "Everyday Life Quiz", type: "quiz", xp: 20, status: "locked" },
    ],
  },
];

/* ─── Quiz data ─────────────────────────────────────────────── */

const quizQuestion = {
  sign: "🙏",
  question: "What does this ISL sign mean?",
  options: ["Hello / Namaste", "Thank You", "Help", "Water"],
  correct: 0,
};

/* ─── Practice activities ────────────────────────────────────── */

const practiceActivities = [
  { id: "tap", label: "Tap the Sign", emoji: "👆", desc: "Tap the correct ISL sign for the word shown" },
  { id: "match", label: "Match Pairs", emoji: "🔗", desc: "Match English words to their ISL signs" },
  { id: "arrange", label: "Arrange Signs", emoji: "📐", desc: "Put the signs in the correct order" },
  { id: "camera", label: "Camera Practice", emoji: "📷", desc: "Sign into the camera — AI checks your form" },
];

/* ─── Helpers ───────────────────────────────────────────────── */

const Stars = ({ n = 0 }: { n: number }) => (
  <div className="flex gap-0.5">
    {[1, 2, 3].map((i) => (
      <span key={i} className={`text-xs ${i <= n ? "text-[#F59E0B]" : "text-[#E8E4F5]"}`}>★</span>
    ))}
  </div>
);

const typeIcon = (type: Lesson["type"]) => {
  if (type === "quiz") return "📝";
  if (type === "checkpoint") return "🏆";
  if (type === "practice") return "🏋️";
  return "📖";
};

/* ─── Views ─────────────────────────────────────────────────── */

type View = "path" | "lesson" | "practice" | "quiz" | "complete" | "achievements";

export default function Learning({ onNavigate }: Props) {
  const [view, setView] = useState<View>("path");
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const [activeUnit, setActiveUnit] = useState<Unit | null>(null);
  const [quizAnswer, setQuizAnswer] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [lessonStep, setLessonStep] = useState(0);
  const [activePractice, setActivePractice] = useState<string | null>(null);
  const [tapAnswer, setTapAnswer] = useState<number | null>(null);

  const xpPct = Math.round((XP / XP_TO_NEXT) * 100);
  const dailyPct = Math.round((DAILY_EARNED_XP / DAILY_GOAL_XP) * 100);

  const openLesson = (lesson: Lesson, unit: Unit) => {
    if (lesson.status === "locked") return;
    setActiveLesson(lesson);
    setActiveUnit(unit);
    setLessonStep(0);
    setQuizAnswer(null);
    setQuizSubmitted(false);
    setActivePractice(null);
    if (lesson.type === "quiz") setView("quiz");
    else if (lesson.type === "practice") setView("practice");
    else setView("lesson");
  };

  /* ── PATH ─────────────────────────────────────── */
  if (view === "path") return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5] sticky top-0 z-30">
        <button onClick={() => onNavigate("home")} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors">←</button>
        <div className="flex-1">
          <div className="font-display font-bold text-[#1A1825] text-base">Learning Module</div>
          <div className="text-[10px] text-[#9CA3AF]">ISL learning path</div>
        </div>
        <button onClick={() => setView("achievements")} className="bg-[#FEF3C7] text-[#D97706] text-xs font-bold px-3 py-1.5 rounded-lg hover:bg-[#FDE68A] transition-colors">
          🏆 Achievements
        </button>
      </header>

      {/* XP + Streak + Daily Goal strip */}
      <div className="bg-white border-b border-[#E8E4F5] px-4 py-3 flex items-center gap-4">
        {/* Streak */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-xl">🔥</span>
          <div>
            <div className="font-display font-bold text-[#1A1825] text-sm leading-none">{STREAK}</div>
            <div className="text-[9px] text-[#9CA3AF] leading-none mt-0.5">day streak</div>
          </div>
        </div>

        <div className="w-px h-8 bg-[#E8E4F5] shrink-0" />

        {/* XP bar */}
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-center mb-1">
            <span className="text-[10px] font-bold text-[#6C5CE7]">Level {LEVEL} · {XP} XP</span>
            <span className="text-[9px] text-[#9CA3AF]">{XP_TO_NEXT - XP} to Level {LEVEL + 1}</span>
          </div>
          <div className="h-2 bg-[#F0EEFF] rounded-full">
            <div className="h-2 bg-[#6C5CE7] rounded-full transition-all" style={{ width: `${xpPct}%` }} />
          </div>
        </div>

        <div className="w-px h-8 bg-[#E8E4F5] shrink-0" />

        {/* Daily goal */}
        <div className="shrink-0 text-right">
          <div className="text-[10px] font-bold text-[#FF7043]">Daily Goal</div>
          <div className="text-[9px] text-[#9CA3AF]">{DAILY_EARNED_XP}/{DAILY_GOAL_XP} XP</div>
          <div className="h-1.5 w-14 bg-[#FFF2EE] rounded-full mt-1">
            <div className="h-1.5 bg-[#FF7043] rounded-full" style={{ width: `${dailyPct}%` }} />
          </div>
        </div>
      </div>

      {/* Learning Path scroll */}
      <div className="flex-1 overflow-y-auto scrollbar-hide pb-28 md:pb-8">
        {units.map((unit, ui) => {
          const unitDone = unit.lessons.every(l => l.status === "done");
          const unitActive = !unitDone && unit.lessons.some(l => l.status !== "locked");
          return (
            <div key={unit.id} className="relative">
              {/* Unit header banner */}
              <div className="mx-4 mt-6 mb-4 rounded-2xl overflow-hidden" style={{ background: `linear-gradient(135deg, ${unit.color}ee, ${unit.color}99)` }}>
                <div className="px-5 py-4 flex items-center justify-between">
                  <div>
                    <div className="text-white/70 text-[10px] font-bold tracking-widest uppercase">{unit.title}</div>
                    <div className="font-display font-bold text-white text-lg">{unit.subtitle}</div>
                    <div className="text-white/70 text-xs mt-0.5">
                      {unit.lessons.filter(l => l.status === "done").length}/{unit.lessons.length} lessons complete
                    </div>
                  </div>
                  <div className="text-4xl">{unit.emoji}</div>
                </div>
                {unitDone && (
                  <div className="bg-white/20 px-5 py-1.5 flex items-center gap-2">
                    <span className="text-white text-xs font-bold">✓ Unit Complete</span>
                    <Stars n={3} />
                  </div>
                )}
              </div>

              {/* Lesson nodes — centred path */}
              <div className="flex flex-col items-center gap-0 px-4 relative">
                {/* Vertical connector line */}
                <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-[#E8E4F5] -translate-x-1/2 z-0" />

                {unit.lessons.map((lesson, li) => {
                  const isLeft = li % 2 === 0;
                  const isDone = lesson.status === "done";
                  const isActive = lesson.status === "active";
                  const isLocked = lesson.status === "locked";
                  const isCheckpoint = lesson.type === "checkpoint";

                  return (
                    <div key={lesson.id} className={`relative z-10 flex items-center w-full mb-3 ${isLeft ? "flex-row" : "flex-row-reverse"}`}>
                      {/* Content bubble */}
                      <div className={`flex-1 ${isLeft ? "pr-6 text-right" : "pl-6 text-left"}`}>
                        {!isLocked && (
                          <div className={`inline-block ${isLeft ? "text-right" : "text-left"}`}>
                            <div className="text-xs font-display font-semibold text-[#1A1825] leading-tight">{lesson.title}</div>
                            {isDone && <div className={`mt-0.5 ${isLeft ? "flex justify-end" : "flex justify-start"}`}><Stars n={lesson.stars || 0} /></div>}
                            {isActive && <div className="text-[10px] text-[#6C5CE7] font-bold mt-0.5 animate-pulse">START →</div>}
                          </div>
                        )}
                      </div>

                      {/* Node button */}
                      <button
                        onClick={() => openLesson(lesson, unit)}
                        disabled={isLocked}
                        className={`relative shrink-0 flex items-center justify-center transition-all duration-200
                          ${isCheckpoint ? "w-16 h-16 rounded-2xl text-2xl" : "w-14 h-14 rounded-full text-xl"}
                          ${isDone ? "shadow-md" : ""}
                          ${isActive ? "ring-4 ring-offset-2 shadow-xl scale-110" : ""}
                          ${isLocked ? "opacity-40 cursor-not-allowed" : "hover:scale-105 active:scale-95"}
                        `}
                        style={{
                          background: isLocked
                            ? "#E8E4F5"
                            : isDone
                              ? unit.color
                              : isActive
                                ? unit.color
                                : "#F0EEFF",
                          ringColor: isActive ? unit.color : undefined,
                          color: isLocked ? "#9CA3AF" : (isDone || isActive) ? "white" : unit.color,
                        }}
                      >
                        {isLocked ? "🔒" : typeIcon(lesson.type)}
                        {/* Done tick */}
                        {isDone && (
                          <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-white flex items-center justify-center text-[10px] font-bold text-[#10B981] border border-[#E8E4F5]">✓</div>
                        )}
                        {/* Active pulse */}
                        {isActive && (
                          <div className="absolute inset-0 rounded-full animate-ping opacity-30" style={{ background: unit.color }} />
                        )}
                        {/* XP badge */}
                        {!isLocked && (
                          <div className="absolute -top-1.5 -right-1 bg-[#FEF3C7] text-[#D97706] text-[8px] font-bold px-1 py-0.5 rounded-full border border-[#FDE68A] leading-none">
                            +{lesson.xp}
                          </div>
                        )}
                      </button>

                      {/* Right label space */}
                      <div className={`flex-1 ${isLeft ? "pl-6 text-left" : "pr-6 text-right"}`}>
                        {isLocked && (
                          <div className="text-xs text-[#C4BBEC] font-medium leading-tight">{lesson.title}</div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}

        {/* End of path */}
        <div className="flex flex-col items-center py-8 px-4">
          <div className="w-16 h-16 rounded-full bg-[#FEF3C7] border-4 border-[#FDE68A] flex items-center justify-center text-3xl mb-3">🏁</div>
          <div className="font-display font-bold text-[#1A1825] text-lg">More coming soon!</div>
          <div className="text-[#9CA3AF] text-sm mt-1">Advanced ISL units are in development</div>
        </div>
      </div>
    </div>
  );

  /* ── LESSON ──────────────────────────────────── */
  if (view === "lesson") {
    const steps = [
      { title: "Watch the Sign", body: "Study the handshape carefully before practicing.", hand: "🙏", sign: activeLesson?.title || "" },
      { title: "Step-by-Step", body: "1. Both palms together at chest\n2. Fingers pointing upward\n3. Hold for 1 second\n4. Slight bow of head", hand: "🤝", sign: "" },
      { title: "Your Turn", body: "Now try it yourself! Use the camera or practice in a mirror.", hand: "🤟", sign: "" },
    ];
    const step = steps[Math.min(lessonStep, steps.length - 1)];
    const progress = ((lessonStep + 1) / steps.length) * 100;

    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5]">
          <button onClick={() => { setView("path"); }} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors">✕</button>
          <div className="flex-1 h-2 bg-[#F0EEFF] rounded-full mx-2">
            <div className="h-2 bg-[#6C5CE7] rounded-full transition-all" style={{ width: `${progress}%` }} />
          </div>
          <div className="text-xs font-bold text-[#6C5CE7]">+{activeLesson?.xp} XP</div>
        </header>

        <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pt-6 pb-8 flex flex-col gap-5">
          <div className="text-center">
            <div className="text-xs font-bold text-[#9CA3AF] tracking-widest mb-1">STEP {lessonStep + 1} OF {steps.length}</div>
            <div className="font-display font-bold text-[#1A1825] text-xl">{step.title}</div>
          </div>

          <div className="bg-[#F0EEFF] rounded-2xl p-8 flex flex-col items-center">
            <div className="text-8xl mb-3">{step.hand}</div>
            {step.sign && <div className="font-display font-bold text-[#6C5CE7] text-xl">{step.sign}</div>}
          </div>

          <div className="bg-white rounded-2xl border border-[#E8E4F5] p-4">
            <p className="text-sm text-[#4A4560] leading-relaxed whitespace-pre-line">{step.body}</p>
          </div>

          {lessonStep === steps.length - 1 ? (
            <button onClick={() => setView("complete")} className="w-full bg-[#6C5CE7] text-white font-display font-bold py-4 rounded-xl text-base hover:bg-[#5A4BD1] transition-colors">
              Complete Lesson 🎉
            </button>
          ) : (
            <button onClick={() => setLessonStep(s => s + 1)} className="w-full bg-[#6C5CE7] text-white font-display font-bold py-4 rounded-xl text-base hover:bg-[#5A4BD1] transition-colors">
              Continue →
            </button>
          )}
        </div>
      </div>
    );
  }

  /* ── PRACTICE ───────────────────────────────── */
  if (view === "practice") {
    const matchPairs = [
      { word: "Hello", sign: "🙏" }, { word: "Water", sign: "💧" },
      { word: "Help", sign: "🆘" }, { word: "Family", sign: "👨‍👩‍👧" },
    ];

    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5]">
          <button onClick={() => setView("path")} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors">✕</button>
          <div className="flex-1 h-2 bg-[#F0EEFF] rounded-full mx-2">
            <div className="h-2 bg-[#00C9A7] rounded-full" style={{ width: activePractice ? "60%" : "0%" }} />
          </div>
          <div className="text-xs font-bold text-[#00C9A7]">+{activeLesson?.xp} XP</div>
        </header>

        <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pt-5 pb-8">
          {!activePractice ? (
            <div className="space-y-4">
              <div className="text-center mb-4">
                <div className="font-display font-bold text-[#1A1825] text-xl mb-1">{activeLesson?.title}</div>
                <div className="text-[#9CA3AF] text-sm">Choose a practice activity</div>
              </div>
              {practiceActivities.map((a) => (
                <button key={a.id} onClick={() => setActivePractice(a.id)}
                  className="w-full bg-white border border-[#E8E4F5] rounded-2xl p-4 flex items-center gap-4 hover:border-[#6C5CE7]/40 hover:shadow-sm transition-all text-left">
                  <div className="w-12 h-12 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-2xl shrink-0">{a.emoji}</div>
                  <div>
                    <div className="font-display font-semibold text-[#1A1825] text-sm">{a.label}</div>
                    <div className="text-xs text-[#9CA3AF] mt-0.5">{a.desc}</div>
                  </div>
                  <div className="ml-auto text-[#9CA3AF]">›</div>
                </button>
              ))}
            </div>
          ) : activePractice === "tap" ? (
            <div className="space-y-5">
              <div className="text-center">
                <div className="font-display font-bold text-[#1A1825] text-xl mb-1">Tap the Sign</div>
                <div className="text-[#9CA3AF] text-sm">Which sign means "Hello"?</div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {["🙏","💧","🆘","👨‍👩‍👧"].map((s, i) => (
                  <button key={i} onClick={() => setTapAnswer(i)}
                    className={`h-28 rounded-2xl flex items-center justify-center text-5xl border-2 transition-all ${
                      tapAnswer === i ? (i === 0 ? "border-[#10B981] bg-[#DCFCE7]" : "border-[#EF4444] bg-[#FEE2E2]") : "border-[#E8E4F5] bg-white hover:border-[#6C5CE7]/40"
                    }`}>{s}</button>
                ))}
              </div>
              {tapAnswer !== null && (
                <div className="space-y-3 fade-in">
                  <div className={`rounded-xl p-3 text-sm font-medium ${tapAnswer === 0 ? "bg-[#DCFCE7] text-[#16A34A]" : "bg-[#FEE2E2] text-[#DC2626]"}`}>
                    {tapAnswer === 0 ? "✅ Correct! 🙏 is Namaste / Hello." : "❌ Not quite. 🙏 (Namaste) means Hello."}
                  </div>
                  <button onClick={() => setView("complete")} className="w-full bg-[#6C5CE7] text-white font-display font-bold py-4 rounded-xl hover:bg-[#5A4BD1] transition-colors">Continue →</button>
                </div>
              )}
            </div>
          ) : activePractice === "match" ? (
            <div className="space-y-5">
              <div className="text-center">
                <div className="font-display font-bold text-[#1A1825] text-xl mb-1">Match Pairs</div>
                <div className="text-[#9CA3AF] text-sm">Match each word to its ISL sign</div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  {matchPairs.map((p) => (
                    <div key={p.word} className="bg-white border-2 border-[#E8E4F5] rounded-xl py-3 px-4 text-sm font-semibold text-[#1A1825] text-center hover:border-[#6C5CE7] cursor-pointer transition-colors">{p.word}</div>
                  ))}
                </div>
                <div className="space-y-2">
                  {matchPairs.map((p) => (
                    <div key={p.sign} className="bg-[#F0EEFF] border-2 border-[#E8E4F5] rounded-xl py-3 px-4 text-2xl text-center hover:border-[#6C5CE7] cursor-pointer transition-colors">{p.sign}</div>
                  ))}
                </div>
              </div>
              <button onClick={() => setView("complete")} className="w-full bg-[#6C5CE7] text-white font-display font-bold py-4 rounded-xl hover:bg-[#5A4BD1] transition-colors">Check Answers →</button>
            </div>
          ) : (
            <div className="text-center py-10">
              <div className="text-5xl mb-4">📷</div>
              <div className="font-display font-bold text-[#1A1825] text-lg mb-2">Camera Practice</div>
              <div className="text-[#9CA3AF] text-sm mb-6">Sign into the camera — our AI will check your form and give instant feedback.</div>
              <button onClick={() => onNavigate("sign-to-speak")} className="bg-[#6C5CE7] text-white font-display font-bold px-6 py-3.5 rounded-xl hover:bg-[#5A4BD1] transition-colors">Open Camera 📷</button>
            </div>
          )}
        </div>
      </div>
    );
  }

  /* ── QUIZ ────────────────────────────────────── */
  if (view === "quiz") {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5]">
          <button onClick={() => setView("path")} className="w-9 h-9 rounded-xl bg-[#FEF3C7] flex items-center justify-center text-[#D97706] text-lg hover:bg-[#FDE68A] transition-colors">✕</button>
          <div className="flex-1 h-2 bg-[#FEF3C7] rounded-full mx-2">
            <div className="h-2 bg-[#F59E0B] rounded-full" style={{ width: quizSubmitted ? "60%" : "20%" }} />
          </div>
          <div className="text-xs font-bold text-[#D97706]">+{activeLesson?.xp} XP</div>
        </header>

        <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pt-6 pb-8 space-y-5">
          <div className="text-center">
            <div className="text-xs font-bold text-[#9CA3AF] tracking-widest mb-1">QUESTION 1 OF 5</div>
            <div className="font-display font-bold text-[#1A1825] text-xl">{quizQuestion.question}</div>
          </div>
          <div className="bg-[#FEF3C7] rounded-2xl p-8 flex items-center justify-center">
            <span className="text-8xl">{quizQuestion.sign}</span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {quizQuestion.options.map((opt, i) => (
              <button key={i} onClick={() => { if (!quizSubmitted) setQuizAnswer(i); }}
                className={`py-4 rounded-xl text-sm font-display font-semibold border-2 transition-all text-center ${
                  quizSubmitted
                    ? i === quizQuestion.correct ? "bg-[#DCFCE7] border-[#16A34A] text-[#16A34A]"
                      : i === quizAnswer ? "bg-[#FEE2E2] border-[#DC2626] text-[#DC2626]"
                      : "bg-white border-[#E8E4F5] text-[#9CA3AF]"
                    : quizAnswer === i ? "bg-[#FEF3C7] border-[#F59E0B] text-[#D97706]"
                      : "bg-white border-[#E8E4F5] text-[#1A1825] hover:border-[#F59E0B]/50"
                }`}>{opt}</button>
            ))}
          </div>
          {!quizSubmitted ? (
            <button onClick={() => setQuizSubmitted(true)} disabled={quizAnswer === null}
              className="w-full bg-[#F59E0B] text-white font-display font-bold py-4 rounded-xl disabled:opacity-40 hover:bg-[#D97706] transition-colors">
              Check Answer
            </button>
          ) : (
            <div className="space-y-3 fade-in">
              <div className={`rounded-xl p-4 text-sm font-medium ${quizAnswer === quizQuestion.correct ? "bg-[#DCFCE7] text-[#16A34A]" : "bg-[#FEE2E2] text-[#DC2626]"}`}>
                {quizAnswer === quizQuestion.correct ? "✅ Correct! Excellent work." : `❌ The answer is "${quizQuestion.options[quizQuestion.correct]}".`}
              </div>
              <button onClick={() => setView("complete")} className="w-full bg-[#F59E0B] text-white font-display font-bold py-4 rounded-xl hover:bg-[#D97706] transition-colors">Next Question →</button>
            </div>
          )}
        </div>
      </div>
    );
  }

  /* ── COMPLETE ─────────────────────────────────── */
  if (view === "complete") {
    return (
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-10 text-center fade-in overflow-y-auto scrollbar-hide">
        <div className="text-7xl mb-4">🎉</div>
        <div className="font-display font-bold text-[#1A1825] text-2xl mb-1">Lesson Complete!</div>
        <div className="text-[#6B7280] text-sm mb-6">Great work on "{activeLesson?.title}"</div>

        {/* XP earned */}
        <div className="bg-[#F0EEFF] border border-[#D8D0FF] rounded-2xl px-8 py-4 mb-6 w-full max-w-xs">
          <div className="font-display font-bold text-[#6C5CE7] text-3xl">+{activeLesson?.xp} XP</div>
          <div className="text-[#9CA3AF] text-sm mt-0.5">added to your total</div>
          <div className="mt-3 h-2 bg-[#E8E4F5] rounded-full">
            <div className="h-2 bg-[#6C5CE7] rounded-full" style={{ width: `${xpPct + 5}%` }} />
          </div>
          <div className="text-[10px] text-[#9CA3AF] mt-1">{XP + (activeLesson?.xp || 0)} / {XP_TO_NEXT} XP to Level {LEVEL + 1}</div>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-3 mb-8 w-full max-w-xs">
          <div className="bg-[#DCFCE7] rounded-xl p-3">
            <div className="font-display font-bold text-[#16A34A] text-lg">98%</div>
            <div className="text-[9px] text-[#6B7280]">Accuracy</div>
          </div>
          <div className="bg-[#FEF3C7] rounded-xl p-3">
            <div className="font-display font-bold text-[#D97706] text-lg">{STREAK}🔥</div>
            <div className="text-[9px] text-[#6B7280]">Day Streak</div>
          </div>
          <div className="bg-[#F0EEFF] rounded-xl p-3">
            <div className="font-display font-bold text-[#6C5CE7] text-lg">Lv.{LEVEL}</div>
            <div className="text-[9px] text-[#6B7280]">Level</div>
          </div>
        </div>

        {/* Stars */}
        <div className="flex gap-3 mb-8">
          {[1, 2, 3].map((i) => (
            <span key={i} className="text-4xl text-[#F59E0B]">★</span>
          ))}
        </div>

        <button onClick={() => setView("path")} className="w-full max-w-xs bg-[#6C5CE7] text-white font-display font-bold py-4 rounded-xl text-base hover:bg-[#5A4BD1] transition-colors mb-3">
          Continue Path →
        </button>
        <button onClick={() => setView("path")} className="text-[#9CA3AF] text-sm hover:text-[#6B7280] transition-colors">Back to Learning Path</button>
      </div>
    );
  }

  /* ── ACHIEVEMENTS ────────────────────────────── */
  if (view === "achievements") {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5]">
          <button onClick={() => setView("path")} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors">←</button>
          <div className="flex-1">
            <div className="font-display font-bold text-[#1A1825] text-base">Badges & Achievements</div>
            <div className="text-[10px] text-[#9CA3AF]">{achievements.filter(a => a.earned).length} of {achievements.length} earned</div>
          </div>
        </header>
        <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pt-5 pb-8">
          <div className="grid grid-cols-2 gap-3">
            {achievements.map((a) => (
              <div key={a.id} className={`bg-white rounded-2xl border p-4 flex flex-col items-center text-center transition-all ${a.earned ? "border-[#FDE68A] shadow-sm" : "border-[#E8E4F5] opacity-50"}`}>
                <div className={`w-14 h-14 rounded-full flex items-center justify-center text-3xl mb-2 ${a.earned ? "bg-[#FEF3C7]" : "bg-[#F4F2FB]"}`}>
                  {a.emoji}
                </div>
                <div className="font-display font-semibold text-[#1A1825] text-sm">{a.label}</div>
                <div className="text-[10px] text-[#9CA3AF] mt-0.5">{a.desc}</div>
                {a.earned && <div className="mt-2 text-[9px] bg-[#DCFCE7] text-[#16A34A] px-2 py-0.5 rounded-full font-bold">EARNED ✓</div>}
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return null;
}
