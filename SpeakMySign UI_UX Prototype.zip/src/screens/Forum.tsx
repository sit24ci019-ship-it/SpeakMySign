import { useState } from "react";
import type { Screen } from "../types";

interface Props {
  onNavigate: (s: Screen) => void;
  showPost?: boolean;
}

const categories = ["All", "Stories", "Help", "Events", "Resources", "Deaf Culture"];

const posts = [
  {
    id: 1, user: "Priya Mehta", avatar: "PM", time: "2h",
    category: "Stories",
    title: "How SpeakMySign changed my daily commute",
    content: "I used to dread asking strangers for directions. Now with Sign to Speak, I just sign and the app speaks for me. Last week a shopkeeper actually learned how to reply in ISL!",
    likes: 142, comments: 38, shares: 12,
    media: true,
    translated: false,
  },
  {
    id: 2, user: "Arjun Krishnan", avatar: "AK", time: "4h",
    category: "Help",
    title: "Looking for ISL practice partner in Bangalore",
    content: "Hi everyone! I'm at Intermediate Level and looking for someone to practice conversational ISL with on weekends. Remote video sessions are great too. DM me!",
    likes: 67, comments: 24, shares: 5,
    media: false,
    translated: false,
  },
  {
    id: 3, user: "Deaf India Network", avatar: "DI", time: "1d",
    category: "Events",
    title: "🎉 ISL Day Workshop — Mumbai, Sep 14",
    content: "Join us for a full-day ISL immersion workshop with certified interpreters. Beginners welcome! Register below.",
    likes: 312, comments: 89, shares: 67,
    media: true,
    translated: false,
  },
  {
    id: 4, user: "Sunita Rao", avatar: "SR", time: "2d",
    category: "Resources",
    title: "Free ISL video dictionary — all 2000 signs",
    content: "Sharing a curated list of YouTube channels and government resources for ISL learning. Completely free! Saved to my profile for easy access.",
    likes: 289, comments: 56, shares: 134,
    media: false,
    translated: false,
  },
];

type View = "feed" | "post" | "create";

export default function Forum({ onNavigate, showPost }: Props) {
  const [view, setView] = useState<View>(showPost ? "post" : "feed");
  const [selectedPost, setSelectedPost] = useState(posts[0]);
  const [activeCategory, setActiveCategory] = useState("All");
  const [liked, setLiked] = useState<number[]>([]);
  const [translated, setTranslated] = useState<number[]>([]);
  const [comment, setComment] = useState("");
  const [newPost, setNewPost] = useState({ title: "", content: "", category: "Stories" });

  const filteredPosts = activeCategory === "All" ? posts : posts.filter(p => p.category === activeCategory);

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5] sticky top-0 z-20">
        <button
          onClick={() => view !== "feed" ? setView("feed") : onNavigate("home")}
          className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors"
        >
          ←
        </button>
        <div className="flex-1">
          <div className="font-display font-bold text-[#1A1825] text-base">
            {view === "feed" ? "Forum to Speak" : view === "post" ? selectedPost.title : "Create Post"}
          </div>
          <div className="text-[10px] text-[#9CA3AF]">
            {view === "feed" ? "ISL Community · 12.4K members" : view === "post" ? `${selectedPost.category}` : "Share with the community"}
          </div>
        </div>
        {view === "feed" && (
          <button onClick={() => setView("create")} className="bg-[#6C5CE7] text-white text-xs font-bold px-3 py-1.5 rounded-lg hover:bg-[#5A4BD1] transition-colors">
            + Post
          </button>
        )}
      </header>

      <div className="flex-1 overflow-y-auto scrollbar-hide pb-24 md:pb-6">

        {/* FEED */}
        {view === "feed" && (
          <div>
            {/* Categories */}
            <div className="px-4 py-3 flex gap-2 overflow-x-auto scrollbar-hide">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => setActiveCategory(c)}
                  className={`shrink-0 text-xs font-semibold px-3.5 py-2 rounded-full transition-all ${
                    activeCategory === c
                      ? "bg-[#6C5CE7] text-white"
                      : "bg-[#F4F2FB] text-[#6B7280] hover:bg-[#E8E4F5]"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>

            {/* Posts */}
            <div className="px-4 space-y-4">
              {filteredPosts.map((post) => (
                <div key={post.id} className="bg-white rounded-2xl border border-[#E8E4F5] overflow-hidden shadow-sm">
                  {/* Author */}
                  <div className="px-4 pt-4 flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-[#6C5CE7] flex items-center justify-center text-white text-xs font-bold shrink-0">
                      {post.avatar}
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-[#1A1825] text-sm">{post.user}</div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-[#9CA3AF]">{post.time} ago</span>
                        <span className="text-[10px] bg-[#F0EEFF] text-[#6C5CE7] px-1.5 py-0.5 rounded-full font-medium">{post.category}</span>
                      </div>
                    </div>
                    <button className="text-[#9CA3AF] text-lg">⋮</button>
                  </div>

                  {/* Content */}
                  <button
                    onClick={() => { setSelectedPost(post); setView("post"); }}
                    className="w-full text-left px-4 pt-2 pb-3"
                  >
                    <div className="font-display font-semibold text-[#1A1825] text-sm mb-1.5">{post.title}</div>
                    <p className="text-xs text-[#4A4560] leading-relaxed line-clamp-3">{post.content}</p>
                  </button>

                  {/* Media placeholder */}
                  {post.media && (
                    <div className="mx-4 mb-3 h-36 bg-[#F4F2FB] rounded-xl flex items-center justify-center border border-[#E8E4F5]">
                      <div className="text-center">
                        <div className="text-3xl mb-1">🎬</div>
                        <div className="text-[11px] text-[#9CA3AF]">Video · Tap to play</div>
                      </div>
                    </div>
                  )}

                  {/* Translate button */}
                  {!translated.includes(post.id) && (
                    <div className="px-4 mb-2">
                      <button
                        onClick={() => setTranslated(prev => [...prev, post.id])}
                        className="text-[11px] text-[#6C5CE7] font-semibold flex items-center gap-1 hover:underline"
                      >
                        🤟 Translate to ISL signs
                      </button>
                    </div>
                  )}
                  {translated.includes(post.id) && (
                    <div className="mx-4 mb-3 bg-[#F0EEFF] rounded-xl p-3 border border-[#D8D0FF]">
                      <div className="text-[10px] text-[#6C5CE7] font-bold mb-1">🤟 ISL TRANSLATION</div>
                      <div className="flex gap-2 overflow-x-auto scrollbar-hide">
                        {["🤙","✊","🖐️","👍","🤚","🤏"].map((h, i) => (
                          <div key={i} className="shrink-0 text-center">
                            <div className="text-2xl">{h}</div>
                            <div className="text-[9px] text-[#9CA3AF]">SIGN</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="px-4 py-3 border-t border-[#F4F2FB] flex items-center gap-4">
                    <button
                      onClick={() => setLiked(prev => prev.includes(post.id) ? prev.filter(i => i !== post.id) : [...prev, post.id])}
                      className={`flex items-center gap-1.5 text-xs font-medium transition-colors ${liked.includes(post.id) ? "text-[#EF4444]" : "text-[#9CA3AF] hover:text-[#EF4444]"}`}
                    >
                      {liked.includes(post.id) ? "❤️" : "🤍"}
                      <span>{post.likes + (liked.includes(post.id) ? 1 : 0)}</span>
                    </button>
                    <button onClick={() => { setSelectedPost(post); setView("post"); }} className="flex items-center gap-1.5 text-xs text-[#9CA3AF] font-medium hover:text-[#6C5CE7] transition-colors">
                      💬 {post.comments}
                    </button>
                    <button className="flex items-center gap-1.5 text-xs text-[#9CA3AF] font-medium hover:text-[#6C5CE7] transition-colors">
                      📤 Share
                    </button>
                    <button className="ml-auto text-xs text-[#9CA3AF] font-medium hover:text-[#6C5CE7] transition-colors">
                      🔖 Save
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* POST DETAIL */}
        {view === "post" && (
          <div className="px-4 pt-5 space-y-4">
            <div className="bg-white rounded-2xl border border-[#E8E4F5] p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-[#6C5CE7] flex items-center justify-center text-white text-sm font-bold">{selectedPost.avatar}</div>
                <div>
                  <div className="font-semibold text-[#1A1825] text-sm">{selectedPost.user}</div>
                  <div className="text-[10px] text-[#9CA3AF]">{selectedPost.time} ago · {selectedPost.category}</div>
                </div>
              </div>
              <div className="font-display font-bold text-[#1A1825] text-lg mb-2">{selectedPost.title}</div>
              <p className="text-sm text-[#4A4560] leading-relaxed">{selectedPost.content}</p>
              {selectedPost.media && (
                <div className="mt-3 h-40 bg-[#F4F2FB] rounded-xl flex items-center justify-center border border-[#E8E4F5]">
                  <div className="text-center"><div className="text-4xl mb-1">🎬</div><div className="text-xs text-[#9CA3AF]">Video</div></div>
                </div>
              )}
            </div>

            {/* Comments */}
            <div>
              <div className="font-display font-semibold text-[#1A1825] mb-3">Comments ({selectedPost.comments})</div>
              {[
                { user: "Meera S.", avatar: "MS", text: "This is so inspiring! I had a similar experience at a hospital last month.", time: "1h" },
                { user: "Ravi T.", avatar: "RT", text: "The shopkeeper learning ISL is the best part of this story 🤟", time: "2h" },
                { user: "Dr. Anjali K.", avatar: "DK", text: "Thank you for sharing. This is why SpeakMySign matters. Accessibility for all!", time: "3h" },
              ].map((c, i) => (
                <div key={i} className="bg-white rounded-xl border border-[#E8E4F5] p-3 mb-2">
                  <div className="flex items-start gap-3">
                    <div className="w-7 h-7 rounded-full bg-[#F0EEFF] flex items-center justify-center text-[10px] text-[#6C5CE7] font-bold shrink-0">{c.avatar}</div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="font-semibold text-xs text-[#1A1825]">{c.user}</span>
                        <span className="text-[9px] text-[#9CA3AF]">{c.time} ago</span>
                      </div>
                      <p className="text-xs text-[#4A4560] leading-relaxed">{c.text}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Comment input */}
            <div className="bg-white rounded-2xl border border-[#E8E4F5] p-3 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-[#6C5CE7] text-white text-xs font-bold flex items-center justify-center">AN</div>
              <input
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Write a comment…"
                className="flex-1 text-sm outline-none text-[#1A1825] placeholder:text-[#9CA3AF]"
              />
              <button className="text-[#6C5CE7] font-bold text-sm hover:text-[#5A4BD1]">Send</button>
            </div>
          </div>
        )}

        {/* CREATE POST */}
        {view === "create" && (
          <div className="px-4 pt-5 space-y-4">
            <div className="bg-white rounded-2xl border border-[#E8E4F5] p-4 space-y-4">
              <div>
                <label className="text-xs font-bold text-[#9CA3AF] tracking-wider">CATEGORY</label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {categories.slice(1).map((c) => (
                    <button
                      key={c}
                      onClick={() => setNewPost(p => ({...p, category: c}))}
                      className={`text-xs px-3 py-1.5 rounded-full font-medium transition-all ${newPost.category === c ? "bg-[#6C5CE7] text-white" : "bg-[#F4F2FB] text-[#6B7280] hover:bg-[#E8E4F5]"}`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs font-bold text-[#9CA3AF] tracking-wider">TITLE</label>
                <input
                  value={newPost.title}
                  onChange={(e) => setNewPost(p => ({...p, title: e.target.value}))}
                  placeholder="What's your post about?"
                  className="w-full mt-1.5 bg-[#F4F2FB] rounded-xl px-4 py-3 text-sm text-[#1A1825] outline-none focus:ring-2 focus:ring-[#6C5CE7]/30"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-[#9CA3AF] tracking-wider">CONTENT</label>
                <textarea
                  value={newPost.content}
                  onChange={(e) => setNewPost(p => ({...p, content: e.target.value}))}
                  placeholder="Share your story, question, or resource with the ISL community…"
                  rows={5}
                  className="w-full mt-1.5 bg-[#F4F2FB] rounded-xl px-4 py-3 text-sm text-[#1A1825] outline-none focus:ring-2 focus:ring-[#6C5CE7]/30 resize-none"
                />
              </div>
              <div className="flex gap-2">
                <button className="flex-1 bg-[#F4F2FB] text-[#6B7280] py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 hover:bg-[#E8E4F5] transition-colors">
                  📸 Add Photo
                </button>
                <button className="flex-1 bg-[#F4F2FB] text-[#6B7280] py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 hover:bg-[#E8E4F5] transition-colors">
                  🎬 Add Video
                </button>
              </div>
            </div>
            <button
              onClick={() => setView("feed")}
              disabled={!newPost.title || !newPost.content}
              className="w-full bg-[#6C5CE7] text-white font-display font-bold py-4 rounded-xl disabled:opacity-40 hover:bg-[#5A4BD1] transition-colors"
            >
              Publish Post
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
