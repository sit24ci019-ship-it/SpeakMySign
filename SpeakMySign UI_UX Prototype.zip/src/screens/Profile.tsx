import type { Screen } from "../types";

interface Props {
  onNavigate: (s: Screen) => void;
}

const STREAK = 7;
const XP = 1240;
const LEVEL = 12;
const XP_TO_NEXT = 1500;
const DAILY_GOAL_XP = 50;
const DAILY_EARNED_XP = 30;

const achievements = [
  { emoji: "🤟", label: "First Sign", earned: true },
  { emoji: "🔥", label: "Week Warrior", earned: true },
  { emoji: "⭐", label: "Level 10", earned: true },
  { emoji: "🔤", label: "Alphabet Master", earned: true },
  { emoji: "🎓", label: "Scholar", earned: false },
  { emoji: "💎", label: "Diamond", earned: false },
];

const unitProgress = [
  { title: "ISL Foundations", pct: 100, color: "#6C5CE7", emoji: "🌱" },
  { title: "Greetings & People", pct: 43, color: "#00C9A7", emoji: "👋" },
  { title: "Numbers & Time", pct: 0, color: "#FF7043", emoji: "🔢" },
  { title: "Family & Relationships", pct: 0, color: "#F59E0B", emoji: "👨‍👩‍👧" },
];

const recentActivity = [
  { icon: "📖", text: "Lesson: Names & Introduction", xp: "+10 XP", time: "Today, 10:30 AM" },
  { icon: "🏆", text: "Earned badge: Week Warrior", xp: "+30 XP", time: "Yesterday" },
  { icon: "📝", text: "Quiz: Alphabet Review — 100%", xp: "+20 XP", time: "2 days ago" },
  { icon: "🏋️", text: "Practice: Match Pairs", xp: "+10 XP", time: "2 days ago" },
];

export default function Profile({ onNavigate }: Props) {
  const xpPct = Math.round((XP / XP_TO_NEXT) * 100);
  const dailyPct = Math.round((DAILY_EARNED_XP / DAILY_GOAL_XP) * 100);

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5]">
        <button onClick={() => onNavigate("home")} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors">←</button>
        <div className="flex-1"><div className="font-display font-bold text-[#1A1825] text-base">My Profile</div></div>
        <button onClick={() => onNavigate("settings")} className="bg-[#F0EEFF] text-[#6C5CE7] text-xs font-bold px-3 py-1.5 rounded-lg hover:bg-[#E8E2FF] transition-colors">
          ⚙️ Settings
        </button>
      </header>

      <div className="flex-1 overflow-y-auto scrollbar-hide pb-24 md:pb-6">
        {/* Profile hero */}
        <div className="bg-gradient-to-br from-[#6C5CE7] to-[#8B7CF8] px-5 py-8 text-center">
          <div className="w-20 h-20 rounded-full bg-white/20 border-4 border-white/40 flex items-center justify-center text-3xl font-display font-bold text-white mx-auto mb-3">
            AN
          </div>
          <div className="font-display font-bold text-white text-xl mb-0.5">Ananya Nair</div>
          <div className="text-white/70 text-sm mb-1">ananya.nair@email.com</div>
          <div className="text-white/60 text-xs mb-4">ISL Learner · Mumbai, India</div>
          <button className="bg-white/20 text-white text-sm font-semibold px-5 py-2 rounded-xl hover:bg-white/30 transition-colors">
            Edit Profile
          </button>
        </div>

        {/* Level + XP card */}
        <div className="mx-4 mt-5 bg-white rounded-2xl border border-[#E8E4F5] p-4 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-[#F0EEFF] flex items-center justify-center font-display font-bold text-[#6C5CE7] text-sm">Lv.{LEVEL}</div>
              <div>
                <div className="font-display font-bold text-[#1A1825] text-base">Level {LEVEL}</div>
                <div className="text-[10px] text-[#9CA3AF]">{XP} / {XP_TO_NEXT} XP</div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-[#9CA3AF]">{XP_TO_NEXT - XP} XP to</div>
              <div className="text-xs font-bold text-[#6C5CE7]">Level {LEVEL + 1}</div>
            </div>
          </div>
          <div className="h-3 bg-[#F0EEFF] rounded-full">
            <div className="h-3 bg-[#6C5CE7] rounded-full transition-all" style={{ width: `${xpPct}%` }} />
          </div>
        </div>

        {/* Streak + Daily goal */}
        <div className="mx-4 mt-3 grid grid-cols-2 gap-3">
          <div className="bg-white rounded-2xl border border-[#E8E4F5] p-4 text-center shadow-sm">
            <div className="text-3xl mb-1">🔥</div>
            <div className="font-display font-bold text-[#1A1825] text-2xl">{STREAK}</div>
            <div className="text-xs text-[#9CA3AF] font-medium">Day Streak</div>
            <div className="mt-2 text-[10px] text-[#FF7043] font-semibold">Keep it going!</div>
          </div>
          <div className="bg-white rounded-2xl border border-[#E8E4F5] p-4 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm font-display font-semibold text-[#1A1825]">Daily Goal</div>
              <div className="text-[10px] font-bold text-[#FF7043]">{DAILY_EARNED_XP}/{DAILY_GOAL_XP} XP</div>
            </div>
            <div className="h-2 bg-[#FFF2EE] rounded-full mb-2">
              <div className="h-2 bg-[#FF7043] rounded-full" style={{ width: `${dailyPct}%` }} />
            </div>
            <div className="flex gap-1">
              {[1,2,3,4,5].map((i) => (
                <div key={i} className={`flex-1 h-1.5 rounded-full ${i <= 3 ? "bg-[#FF7043]" : "bg-[#FFF2EE]"}`} />
              ))}
            </div>
            <div className="text-[9px] text-[#9CA3AF] mt-1.5">3 / 5 activities</div>
          </div>
        </div>

        {/* Quick stats */}
        <div className="mx-4 mt-3 bg-white rounded-2xl border border-[#E8E4F5] divide-x divide-[#F4F2FB] flex shadow-sm overflow-hidden">
          {[["124", "Signs Learned"], ["18", "Lessons Done"], ["4", "Badges"], ["24h", "Practice"]].map(([v, l]) => (
            <div key={l} className="flex-1 py-3.5 text-center">
              <div className="font-display font-bold text-[#6C5CE7] text-lg">{v}</div>
              <div className="text-[9px] text-[#9CA3AF] font-medium mt-0.5 leading-tight px-1">{l}</div>
            </div>
          ))}
        </div>

        <div className="px-4 pt-5 space-y-5">
          {/* Learning progress */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="font-display font-semibold text-[#1A1825]">Learning Progress</div>
              <button onClick={() => onNavigate("learning")} className="text-xs text-[#6C5CE7] font-semibold hover:underline">View Path →</button>
            </div>
            <div className="space-y-2.5">
              {unitProgress.map((u) => (
                <div key={u.title} className="bg-white rounded-xl border border-[#E8E4F5] p-3.5 flex items-center gap-3">
                  <div className="text-xl w-8 text-center">{u.emoji}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm font-medium text-[#1A1825] truncate">{u.title}</span>
                      <span className="text-xs font-bold ml-2 shrink-0" style={{ color: u.color }}>{u.pct}%</span>
                    </div>
                    <div className="h-1.5 bg-[#F4F2FB] rounded-full">
                      <div className="h-1.5 rounded-full transition-all" style={{ width: `${u.pct}%`, background: u.color }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Badges */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="font-display font-semibold text-[#1A1825]">Badges</div>
              <button onClick={() => onNavigate("learning")} className="text-xs text-[#6C5CE7] font-semibold hover:underline">All achievements →</button>
            </div>
            <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-1">
              {achievements.map((a, i) => (
                <div key={i} className={`shrink-0 flex flex-col items-center gap-1 ${!a.earned ? "opacity-30" : ""}`}>
                  <div className={`w-14 h-14 rounded-full flex items-center justify-center text-2xl border-2 ${a.earned ? "bg-[#FEF3C7] border-[#FDE68A]" : "bg-[#F4F2FB] border-[#E8E4F5]"}`}>
                    {a.emoji}
                  </div>
                  <div className="text-[9px] text-[#6B7280] font-medium text-center whitespace-nowrap">{a.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent activity */}
          <div>
            <div className="font-display font-semibold text-[#1A1825] mb-3">Recent Activity</div>
            <div className="space-y-2">
              {recentActivity.map((a, i) => (
                <div key={i} className="bg-white rounded-xl border border-[#E8E4F5] p-3 flex items-center gap-3">
                  <span className="text-xl w-7 text-center">{a.icon}</span>
                  <div className="flex-1">
                    <div className="text-xs text-[#1A1825] font-medium">{a.text}</div>
                    <div className="text-[10px] text-[#9CA3AF]">{a.time}</div>
                  </div>
                  <span className="text-[10px] font-bold text-[#6C5CE7] bg-[#F0EEFF] px-2 py-0.5 rounded-full shrink-0">{a.xp}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
