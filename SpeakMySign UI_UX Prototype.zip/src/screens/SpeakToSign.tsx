import { useState } from "react";
import type { Screen } from "../types";

interface Props {
  onNavigate: (s: Screen) => void;
}

type InputMode = "text" | "voice";
type TranslateState = "idle" | "listening" | "translating" | "result";

const samplePhrases = ["Hello, how are you?", "Please help me", "I need water", "Thank you very much", "Where is the hospital?", "Call my family"];

const signFrames = [
  { letter: "N", hand: "🤙", label: "N" },
  { letter: "A", hand: "✊", label: "A" },
  { letter: "M", hand: "🖐️", label: "M" },
  { letter: "A", hand: "✊", label: "A" },
  { letter: "S", hand: "🤏", label: "S" },
  { letter: "T", hand: "👍", label: "T" },
  { letter: "E", hand: "🤚", label: "E" },
];

export default function SpeakToSign({ onNavigate }: Props) {
  const [inputMode, setInputMode] = useState<InputMode>("text");
  const [text, setText] = useState("");
  const [translateState, setTranslateState] = useState<TranslateState>("idle");
  const [activeFrame, setActiveFrame] = useState(0);
  const [speed, setSpeed] = useState(1.0);

  const handleTranslate = () => {
    if (!text.trim()) return;
    setTranslateState("translating");
    setTimeout(() => {
      setTranslateState("result");
      setActiveFrame(0);
    }, 1500);
  };

  const handleVoice = () => {
    setInputMode("voice");
    setTranslateState("listening");
    setTimeout(() => {
      setText("Hello, how are you?");
      setTranslateState("idle");
    }, 2500);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5] sticky top-0 z-20">
        <button onClick={() => onNavigate("home")} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors">
          ←
        </button>
        <div className="flex-1">
          <div className="font-display font-bold text-[#1A1825] text-base">Speak to Sign</div>
          <div className="text-[10px] text-[#9CA3AF]">Voice & Text → ISL</div>
        </div>
        <button className="bg-[#F0EEFF] text-[#6C5CE7] text-xs font-bold px-3 py-1.5 rounded-lg">History</button>
      </header>

      <div className="flex-1 overflow-y-auto scrollbar-hide pb-6">
        {/* Input mode toggle */}
        <div className="px-4 pt-5 pb-3">
          <div className="bg-[#F4F2FB] rounded-xl p-1 flex">
            {(["text","voice"] as InputMode[]).map((m) => (
              <button
                key={m}
                onClick={() => { setInputMode(m); setTranslateState("idle"); }}
                className={`flex-1 py-2.5 rounded-lg text-sm font-display font-semibold transition-all flex items-center justify-center gap-2 ${
                  inputMode === m ? "bg-white text-[#6C5CE7] shadow-sm" : "text-[#6B7280]"
                }`}
              >
                <span>{m === "text" ? "⌨️" : "🎤"}</span>
                <span>{m === "text" ? "Type Text" : "Voice Input"}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Input area */}
        <div className="px-4 pb-4">
          <div className="bg-white rounded-2xl border-2 border-[#E8E4F5] focus-within:border-[#6C5CE7] transition-colors p-4">
            {inputMode === "text" ? (
              <textarea
                value={text}
                onChange={(e) => { setText(e.target.value); setTranslateState("idle"); }}
                placeholder="Type something to translate into ISL signs…"
                className="w-full text-[#1A1825] text-sm resize-none outline-none leading-relaxed bg-transparent"
                rows={4}
              />
            ) : (
              <div className="flex flex-col items-center py-2">
                {translateState === "listening" ? (
                  <>
                    <div className="w-16 h-16 rounded-full bg-[#EF4444]/10 border-2 border-[#EF4444] flex items-center justify-center mb-3 animate-pulse">
                      <span className="text-2xl">🎤</span>
                    </div>
                    <div className="flex items-center gap-1 mb-1">
                      {[1,2,3,4,5].map((i) => <div key={i} className="w-1.5 bg-[#EF4444] rounded-full wave-bar" style={{height:`${8+i*3}px`}} />)}
                    </div>
                    <div className="text-[#EF4444] text-sm font-semibold">Listening…</div>
                  </>
                ) : (
                  <>
                    <button onClick={handleVoice} className="w-16 h-16 rounded-full bg-[#6C5CE7] flex items-center justify-center mb-3 hover:bg-[#5A4BD1] transition-colors shadow-lg">
                      <span className="text-2xl">🎤</span>
                    </button>
                    <div className="text-[#6B7280] text-sm">Tap to speak</div>
                    {text && <div className="mt-2 text-[#1A1825] text-sm font-medium text-center">"{text}"</div>}
                  </>
                )}
              </div>
            )}
          </div>

          {/* Quick phrases */}
          <div className="mt-3">
            <div className="text-xs text-[#9CA3AF] font-medium mb-2">Quick phrases:</div>
            <div className="flex flex-wrap gap-2">
              {samplePhrases.map((p) => (
                <button
                  key={p}
                  onClick={() => { setText(p); setTranslateState("idle"); setInputMode("text"); }}
                  className="text-xs bg-[#F0EEFF] text-[#6C5CE7] px-3 py-1.5 rounded-lg font-medium hover:bg-[#E8E2FF] transition-colors"
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* Translate button */}
          <button
            onClick={handleTranslate}
            disabled={!text.trim() || translateState === "translating"}
            className="w-full mt-4 bg-gradient-to-r from-[#00C9A7] to-[#00B4D8] text-white font-display font-bold py-4 rounded-xl text-base disabled:opacity-40 disabled:cursor-not-allowed hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
          >
            {translateState === "translating" ? (
              <>
                <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                Translating…
              </>
            ) : (
              <>🤟 Translate to ISL</>
            )}
          </button>
        </div>

        {/* Result */}
        {translateState === "result" && (
          <div className="px-4 fade-in">
            <div className="bg-white rounded-2xl border border-[#E8E4F5] overflow-hidden shadow-sm">
              {/* Header */}
              <div className="px-4 py-3 bg-gradient-to-r from-[#00C9A7] to-[#00B4D8] flex items-center justify-between">
                <div>
                  <div className="text-white font-display font-bold text-sm">ISL Translation</div>
                  <div className="text-white/70 text-xs mt-0.5">"{text}"</div>
                </div>
                <button className="bg-white/20 text-white text-xs px-3 py-1.5 rounded-lg font-semibold hover:bg-white/30 transition-colors">
                  Save
                </button>
              </div>

              {/* Sign animation area */}
              <div className="p-4">
                {/* Big sign display */}
                <div className="bg-[#F4F2FB] rounded-xl p-6 flex items-center justify-center mb-4 min-h-32">
                  <div className="text-center">
                    <div className="text-7xl mb-2">{signFrames[activeFrame]?.hand}</div>
                    <div className="font-display font-bold text-[#6C5CE7] text-xl">{signFrames[activeFrame]?.label}</div>
                    <div className="text-[#9CA3AF] text-xs mt-1">Frame {activeFrame + 1} / {signFrames.length}</div>
                  </div>
                </div>

                {/* Sign frames strip */}
                <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1 mb-4">
                  {signFrames.map((f, i) => (
                    <button
                      key={i}
                      onClick={() => setActiveFrame(i)}
                      className={`shrink-0 w-14 h-14 rounded-xl flex flex-col items-center justify-center gap-0.5 border-2 transition-all ${
                        activeFrame === i
                          ? "border-[#00C9A7] bg-[#E6FAF7]"
                          : "border-[#E8E4F5] bg-white hover:border-[#00C9A7]/50"
                      }`}
                    >
                      <span className="text-xl">{f.hand}</span>
                      <span className="text-[9px] font-bold text-[#6B7280]">{f.letter}</span>
                    </button>
                  ))}
                </div>

                {/* Playback controls */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setActiveFrame((i) => Math.max(0, i - 1))}
                      className="w-9 h-9 rounded-xl bg-[#F0EEFF] text-[#6C5CE7] flex items-center justify-center hover:bg-[#E8E2FF] transition-colors"
                    >←</button>
                    <button
                      onClick={() => setActiveFrame((i) => (i + 1) % signFrames.length)}
                      className="w-10 h-10 rounded-xl bg-[#6C5CE7] text-white flex items-center justify-center hover:bg-[#5A4BD1] transition-colors"
                    >▶</button>
                    <button
                      onClick={() => setActiveFrame((i) => Math.min(signFrames.length - 1, i + 1))}
                      className="w-9 h-9 rounded-xl bg-[#F0EEFF] text-[#6C5CE7] flex items-center justify-center hover:bg-[#E8E2FF] transition-colors"
                    >→</button>
                  </div>
                  {/* Speed control */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-[#9CA3AF]">Speed:</span>
                    {[0.5, 1.0, 1.5, 2.0].map((s) => (
                      <button
                        key={s}
                        onClick={() => setSpeed(s)}
                        className={`text-xs px-2 py-1 rounded-lg font-bold transition-all ${
                          speed === s ? "bg-[#6C5CE7] text-white" : "bg-[#F4F2FB] text-[#6B7280]"
                        }`}
                      >
                        {s}×
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Word-by-word breakdown */}
              <div className="border-t border-[#E8E4F5] px-4 py-3">
                <div className="text-xs font-bold text-[#9CA3AF] mb-2 tracking-wider">WORD BREAKDOWN</div>
                <div className="flex flex-wrap gap-2">
                  {text.split(" ").slice(0, 6).map((word, i) => (
                    <div key={i} className="bg-[#F4F2FB] rounded-lg px-2.5 py-1.5 text-center">
                      <div className="text-lg">🤟</div>
                      <div className="text-[10px] font-bold text-[#6C5CE7] mt-0.5">{word.toUpperCase().replace(/[^A-Z]/g,"")}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
