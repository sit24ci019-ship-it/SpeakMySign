import type { Screen } from "../types";

interface Props {
  onNavigate: (s: Screen) => void;
}

const features = [
  {
    id: "sign-to-speak" as Screen,
    emoji: "🤟",
    title: "Sign to Speak",
    desc: "Point your camera at ISL signs — SpeakMySign reads them aloud for you in real time.",
    tag: "AI-Powered",
    gradient: "from-[#6C5CE7] to-[#8B7CF8]",
    bg: "bg-gradient-to-br from-[#6C5CE7] to-[#8B7CF8]",
    light: "bg-[#F0EEFF]",
    textLight: "text-[#6C5CE7]",
    badge: "bg-white/20 text-white",
  },
  {
    id: "speak-to-sign" as Screen,
    emoji: "🗣️",
    title: "Speak to Sign",
    desc: "Type or speak anything — watch it transform into animated ISL signs instantly.",
    tag: "Voice + Text",
    gradient: "from-[#00C9A7] to-[#00B4D8]",
    bg: "bg-gradient-to-br from-[#00C9A7] to-[#00B4D8]",
    light: "bg-[#E6FAF7]",
    textLight: "text-[#00907A]",
    badge: "bg-white/20 text-white",
  },
  {
    id: "learning" as Screen,
    emoji: "📚",
    title: "Learning Module",
    desc: "Structured ISL lessons, quizzes and progress tracking — beginner to advanced.",
    tag: "12 Lessons",
    gradient: "from-[#FF7043] to-[#FF9A3C]",
    bg: "bg-gradient-to-br from-[#FF7043] to-[#FF9A3C]",
    light: "bg-[#FFF2EE]",
    textLight: "text-[#D45A32]",
    badge: "bg-white/20 text-white",
  },
];

const quickLinks = [
  { emoji: "📖", label: "ISL Dictionary", screen: "dictionary" as Screen },
  { emoji: "🤖", label: "AI Tutor", screen: "ai-tutor" as Screen },
  { emoji: "⚡", label: "Quick Phrases", screen: "quick-phrases" as Screen },
];

const forumPosts = [
  { user: "Priya M.", avatar: "P", time: "2h", text: "Just completed Level 3! The hand-shape exercises really helped. Anyone else practicing the number signs?", likes: 24, replies: 8 },
  { user: "Arjun K.", avatar: "A", time: "5h", text: "Looking for a study partner for ISL practice sessions on weekends. DM me!", likes: 17, replies: 12 },
];

export default function Home({ onNavigate }: Props) {
  return (
    <div className="flex-1 overflow-y-auto scrollbar-hide pb-24 md:pb-6">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-[#FFFDF9]/95 backdrop-blur-sm border-b border-[#E8E4F5] px-5 py-4 flex items-center justify-between">
        <div>
          <div className="font-display font-bold text-xl text-[#1A1825]">SpeakMySign</div>
          <div className="text-xs text-[#6B7280] font-medium">Good morning, Ananya 👋</div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => onNavigate("settings")} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-lg hover:bg-[#E8E2FF] transition-colors">
            🔔
          </button>
          <button onClick={() => onNavigate("profile")} className="w-9 h-9 rounded-full bg-[#6C5CE7] flex items-center justify-center text-white font-display font-bold text-sm hover:bg-[#5A4BD1] transition-colors">
            AN
          </button>
        </div>
      </header>

      <div className="px-5 pt-5 space-y-7">
        {/* Primary Feature Cards */}
        <div>
          <div className="font-display font-bold text-[#1A1825] text-lg mb-3">Communication</div>
          <div className="space-y-3">
            {features.map((f) => (
              <button
                key={f.id}
                onClick={() => onNavigate(f.id)}
                className="w-full text-left rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-200 active:scale-[0.98]"
              >
                <div className={`${f.bg} p-5`}>
                  <div className="flex items-start justify-between mb-3">
                    <div className="text-4xl">{f.emoji}</div>
                    <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${f.badge}`}>
                      {f.tag}
                    </span>
                  </div>
                  <div className="font-display font-bold text-white text-xl mb-1">{f.title}</div>
                  <div className="text-white/80 text-sm leading-relaxed">{f.desc}</div>
                  <div className="mt-3 flex items-center gap-1.5 text-white text-xs font-semibold">
                    <span>Open</span>
                    <span>→</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <div className="font-display font-bold text-[#1A1825] text-lg mb-3">Quick Access</div>
          <div className="grid grid-cols-3 gap-3">
            {quickLinks.map((q) => (
              <button
                key={q.screen}
                onClick={() => onNavigate(q.screen)}
                className="bg-white border border-[#E8E4F5] rounded-2xl p-4 flex flex-col items-center gap-2 hover:border-[#6C5CE7] hover:bg-[#F8F6FF] transition-all active:scale-95 shadow-sm"
              >
                <span className="text-2xl">{q.emoji}</span>
                <span className="text-xs font-display font-semibold text-[#1A1825] text-center leading-tight">{q.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* SOS Emergency — NOT a card, a distinct action strip */}
        <div>
          <div className="font-display font-bold text-[#1A1825] text-lg mb-3">Emergency</div>
          <button
            onClick={() => onNavigate("sos")}
            className="w-full flex items-center gap-4 bg-[#FEF2F2] border-2 border-[#FECACA] rounded-2xl px-5 py-4 hover:bg-[#FEE2E2] hover:border-[#FCA5A5] transition-all active:scale-[0.98]"
          >
            <div className="w-12 h-12 rounded-full bg-[#EF4444] flex items-center justify-center text-2xl sos-pulse shrink-0">
              🚨
            </div>
            <div className="text-left flex-1">
              <div className="font-display font-bold text-[#DC2626] text-base">SOS Emergency</div>
              <div className="text-[#7F1D1D] text-xs mt-0.5">Tap to alert contacts · Works offline</div>
            </div>
            <div className="text-[#DC2626] text-xl">›</div>
          </button>
          <div className="mt-2 text-[10px] text-[#9CA3AF] text-center">
            Configurable via volume buttons — phone-based only, no external hardware
          </div>
        </div>

        {/* Forum to Speak — NOT a card */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="font-display font-bold text-[#1A1825] text-lg">💬 Forum to Speak</div>
            <button onClick={() => onNavigate("forum")} className="text-xs text-[#6C5CE7] font-semibold hover:underline">
              View all
            </button>
          </div>
          <div className="bg-[#F8F6FF] rounded-2xl border border-[#E8E4F5] overflow-hidden">
            <div className="px-4 py-3 border-b border-[#E8E4F5] flex items-center gap-3">
              <div className="flex-1 bg-white rounded-xl px-4 py-2.5 text-sm text-[#9CA3AF] border border-[#E8E4F5] cursor-pointer hover:border-[#6C5CE7] transition-colors">
                Share something with the community...
              </div>
              <button onClick={() => onNavigate("forum")} className="bg-[#6C5CE7] text-white text-xs font-bold px-3 py-2.5 rounded-xl hover:bg-[#5A4BD1] transition-colors whitespace-nowrap">
                + Post
              </button>
            </div>
            {forumPosts.map((post, i) => (
              <button key={i} onClick={() => onNavigate("forum-post")} className="w-full text-left px-4 py-3 border-b border-[#E8E4F5] last:border-0 hover:bg-white/50 transition-colors">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#6C5CE7] flex items-center justify-center text-white text-xs font-bold shrink-0">
                    {post.avatar}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-xs text-[#1A1825]">{post.user}</span>
                      <span className="text-[10px] text-[#9CA3AF]">{post.time} ago</span>
                    </div>
                    <p className="text-xs text-[#4A4560] leading-relaxed line-clamp-2">{post.text}</p>
                    <div className="flex items-center gap-3 mt-2">
                      <span className="text-[10px] text-[#9CA3AF]">❤️ {post.likes}</span>
                      <span className="text-[10px] text-[#9CA3AF]">💬 {post.replies}</span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="h-4" />
      </div>
    </div>
  );
}
