import { useState } from "react";
import type { Screen } from "../types";

interface Props {
  onNavigate: (s: Screen) => void;
}

const phraseCategories = [
  {
    id: "everyday",
    label: "Everyday",
    emoji: "💬",
    color: "bg-[#6C5CE7]",
    phrases: [
      { text: "Hello! How are you?", isl: "NAMASTE! KAISA HAIN AAP?" },
      { text: "Thank you very much", isl: "BAHUT SHUKRIYA" },
      { text: "Please help me", isl: "MERI MADAD KAREIN" },
      { text: "I don't understand", isl: "MUJHE SAMAJH NAHIN AAYA" },
      { text: "Can you repeat that?", isl: "KYA AAP DOBARA BOLENGE?" },
      { text: "I am deaf / hard of hearing", isl: "MAIN BAHRA/BAHARI HOON" },
    ],
  },
  {
    id: "emergency",
    label: "Emergency",
    emoji: "🚨",
    color: "bg-[#EF4444]",
    phrases: [
      { text: "Help! Emergency!", isl: "MADAD! AAPAT STHITI!" },
      { text: "Call the police", isl: "POLICE KO BULAYEIN" },
      { text: "I need a doctor", isl: "MUJHE DOCTOR CHAHIYE" },
      { text: "I am injured", isl: "MUJHE CHOT LAGI HAI" },
      { text: "Where is the hospital?", isl: "ASPATAL KAHAN HAI?" },
      { text: "I am lost", isl: "MAIN KHO GAYA/GAYI HOON" },
    ],
  },
  {
    id: "travel",
    label: "Travel",
    emoji: "🚌",
    color: "bg-[#00C9A7]",
    phrases: [
      { text: "Where is the bus stop?", isl: "BUS ADDA KAHAN HAI?" },
      { text: "How much does this cost?", isl: "ISKA KITNA DAAM HAI?" },
      { text: "I need to go to...", isl: "MUJHE JANA HAI..." },
      { text: "Please write it down", isl: "PLEASE LIKHKAR DIJIYE" },
      { text: "I need water", isl: "MUJHE PAANI CHAHIYE" },
      { text: "Thank you for your patience", isl: "DHAIRYA RAKHNE KA SHUKRIYA" },
    ],
  },
  {
    id: "family",
    label: "Family",
    emoji: "👨‍👩‍👧",
    color: "bg-[#FF7043]",
    phrases: [
      { text: "I love you", isl: "MAIN AAPKO PYAAR KARTA/KARTI HOON" },
      { text: "Are you okay?", isl: "KYA AAP THEEK HAIN?" },
      { text: "Where are you?", isl: "AAP KAHAN HAIN?" },
      { text: "Come home safely", isl: "SURAKSHIT GHAR AAIYE" },
    ],
  },
];

export default function QuickPhrases({ onNavigate }: Props) {
  const [activeCategory, setActiveCategory] = useState(phraseCategories[0]);
  const [activePhraseIdx, setActivePhraseIdx] = useState<number | null>(null);
  const [speaking, setSpeaking] = useState<number | null>(null);

  const speak = (i: number) => {
    setSpeaking(i);
    setTimeout(() => setSpeaking(null), 1800);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5]">
        <button onClick={() => onNavigate("home")} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors">←</button>
        <div className="flex-1">
          <div className="font-display font-bold text-[#1A1825] text-base">Quick Phrases</div>
          <div className="text-[10px] text-[#9CA3AF]">Tap to speak or show ISL</div>
        </div>
      </header>

      {/* Category tabs */}
      <div className="flex gap-2 px-4 py-3 overflow-x-auto scrollbar-hide bg-white border-b border-[#E8E4F5]">
        {phraseCategories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => { setActiveCategory(cat); setActivePhraseIdx(null); }}
            className={`shrink-0 flex items-center gap-1.5 text-xs font-semibold px-3.5 py-2 rounded-full transition-all ${
              activeCategory.id === cat.id ? `${cat.color} text-white` : "bg-[#F4F2FB] text-[#6B7280] hover:bg-[#E8E4F5]"
            }`}
          >
            <span>{cat.emoji}</span>
            <span>{cat.label}</span>
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pt-4 pb-24 md:pb-6 space-y-2">
        {activeCategory.phrases.map((phrase, i) => (
          <div key={i} className={`bg-white rounded-2xl border overflow-hidden transition-all ${activePhraseIdx === i ? "border-[#6C5CE7]" : "border-[#E8E4F5]"}`}>
            {/* Phrase row */}
            <button
              onClick={() => setActivePhraseIdx(activePhraseIdx === i ? null : i)}
              className="w-full flex items-center gap-3 px-4 py-4 text-left hover:bg-[#FAFAF8] transition-colors"
            >
              <div className={`w-8 h-8 rounded-xl ${activeCategory.color} flex items-center justify-center text-sm shrink-0`}>
                {activeCategory.emoji}
              </div>
              <div className="flex-1">
                <div className="font-semibold text-[#1A1825] text-sm">{phrase.text}</div>
                {activePhraseIdx === i && (
                  <div className="text-xs text-[#6C5CE7] mt-0.5 font-medium">{phrase.isl}</div>
                )}
              </div>
              <div className={`text-[#9CA3AF] transition-transform ${activePhraseIdx === i ? "rotate-90" : ""}`}>›</div>
            </button>

            {/* Expanded actions */}
            {activePhraseIdx === i && (
              <div className="px-4 pb-4 fade-in">
                {/* ISL translation preview */}
                <div className="bg-[#F0EEFF] rounded-xl p-3 mb-3 flex items-center gap-3">
                  <div className="text-3xl">🤟</div>
                  <div>
                    <div className="text-[10px] text-[#6C5CE7] font-bold mb-0.5">ISL TRANSLATION</div>
                    <div className="text-xs text-[#4A4560] font-medium">{phrase.isl}</div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => speak(i)}
                    className={`flex flex-col items-center gap-1 py-3 rounded-xl text-xs font-semibold transition-all ${
                      speaking === i ? "bg-[#10B981] text-white" : "bg-[#6C5CE7] text-white hover:bg-[#5A4BD1]"
                    }`}
                  >
                    {speaking === i ? (
                      <>
                        <div className="flex gap-0.5">
                          {[1,2,3].map((b) => <div key={b} className="w-0.5 bg-white wave-bar" style={{height:"10px"}} />)}
                        </div>
                        <span>Speaking…</span>
                      </>
                    ) : (
                      <><span className="text-base">🔊</span><span>Speak</span></>
                    )}
                  </button>
                  <button className="flex flex-col items-center gap-1 py-3 bg-[#F0EEFF] text-[#6C5CE7] rounded-xl text-xs font-semibold hover:bg-[#E8E2FF] transition-colors">
                    <span className="text-base">🤟</span><span>Show ISL</span>
                  </button>
                  <button className="flex flex-col items-center gap-1 py-3 bg-[#F4F2FB] text-[#6B7280] rounded-xl text-xs font-semibold hover:bg-[#E8E4F5] transition-colors">
                    <span className="text-base">📤</span><span>Share</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
