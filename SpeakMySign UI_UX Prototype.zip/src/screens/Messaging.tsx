import { useState } from "react";
import type { Screen } from "../types";

interface Props {
  onNavigate: (s: Screen) => void;
}

const conversations = [
  { id: 1, name: "Priya Mehta", avatar: "PM", lastMsg: "🤟 Sign sent", time: "2m", unread: 3, online: true },
  { id: 2, name: "ISL Study Group", avatar: "SG", lastMsg: "Arjun: See you at 6pm!", time: "15m", unread: 7, online: true, group: true },
  { id: 3, name: "Ravi Tiwari", avatar: "RT", lastMsg: "Thanks for the sign tips!", time: "1h", unread: 0, online: false },
  { id: 4, name: "Deaf India Network", avatar: "DI", lastMsg: "New event posted 📅", time: "3h", unread: 1, online: true, group: true },
  { id: 5, name: "Dr. Anjali Kumar", avatar: "AK", lastMsg: "Voice message · 0:23", time: "1d", unread: 0, online: false },
];

type MsgType = "text" | "voice" | "image" | "sign-video" | "sign-action";
interface Msg {
  id: number;
  from: "me" | "them";
  type: MsgType;
  content: string;
  time: string;
  signAction?: string;
}

const initialMessages: Msg[] = [
  { id: 1, from: "them", type: "text", content: "Hey Ananya! Can you help me with the ISL sign for 'hospital'?", time: "10:02 AM" },
  { id: 2, from: "me", type: "text", content: "Of course! Let me send you the sign video for that.", time: "10:03 AM" },
  { id: 3, from: "me", type: "sign-video", content: "ISL Sign: HOSPITAL", time: "10:03 AM" },
  { id: 4, from: "them", type: "voice", content: "Voice message · 0:14", time: "10:05 AM" },
  { id: 5, from: "them", type: "sign-action", content: "🤟 Signed: SHUKRIYA (Thank You)", time: "10:06 AM", signAction: "Sign→Text" },
  { id: 6, from: "me", type: "text", content: "You're welcome! Practice it a few times and let me know how it goes 😊", time: "10:07 AM" },
  { id: 7, from: "them", type: "image", content: "Photo from camera", time: "10:10 AM" },
  { id: 8, from: "me", type: "text", content: "Great form! Your handshape is almost perfect 🤟", time: "10:11 AM" },
];

type View = "list" | "chat";
type SpeakMySignAction = "Sign→Text" | "Sign→Speech" | "Text→Sign" | "Voice→Sign";

export default function Messaging({ onNavigate }: Props) {
  const [view, setView] = useState<View>("list");
  const [selectedConv, setSelectedConv] = useState(conversations[0]);
  const [messages, setMessages] = useState<Msg[]>(initialMessages);
  const [input, setInput] = useState("");
  const [showSMSMenu, setShowSMSMenu] = useState<number | null>(null);
  const [showAttach, setShowAttach] = useState(false);

  const smsActions: SpeakMySignAction[] = ["Sign→Text", "Sign→Speech", "Text→Sign", "Voice→Sign"];

  const sendMessage = () => {
    if (!input.trim()) return;
    setMessages(prev => [...prev, {
      id: Date.now(), from: "me", type: "text",
      content: input, time: new Date().toLocaleTimeString("en-IN", {hour:"2-digit", minute:"2-digit"})
    }]);
    setInput("");
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {view === "list" ? (
        <>
          {/* Header */}
          <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5] sticky top-0 z-20">
            <button onClick={() => onNavigate("home")} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors">←</button>
            <div className="flex-1">
              <div className="font-display font-bold text-[#1A1825] text-base">Messages</div>
              <div className="text-[10px] text-[#9CA3AF]">5 conversations</div>
            </div>
            <button className="w-9 h-9 rounded-xl bg-[#6C5CE7] flex items-center justify-center text-white hover:bg-[#5A4BD1] transition-colors">✏️</button>
          </header>

          {/* Search */}
          <div className="px-4 py-3 bg-white border-b border-[#E8E4F5]">
            <div className="bg-[#F4F2FB] rounded-xl px-4 py-2.5 flex items-center gap-2">
              <span className="text-[#9CA3AF]">🔍</span>
              <input placeholder="Search conversations…" className="flex-1 text-sm bg-transparent outline-none text-[#1A1825] placeholder:text-[#9CA3AF]" />
            </div>
          </div>

          {/* Conversation list */}
          <div className="flex-1 overflow-y-auto scrollbar-hide pb-24 md:pb-6">
            {conversations.map((conv) => (
              <button
                key={conv.id}
                onClick={() => { setSelectedConv(conv); setView("chat"); }}
                className="w-full flex items-center gap-3 px-4 py-3.5 border-b border-[#F4F2FB] hover:bg-[#FAFAF8] transition-colors text-left"
              >
                <div className="relative shrink-0">
                  <div className="w-12 h-12 rounded-full bg-[#6C5CE7] flex items-center justify-center text-white text-sm font-bold">
                    {conv.avatar}
                  </div>
                  {conv.online && <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-[#10B981] border-2 border-white" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="font-semibold text-[#1A1825] text-sm">{conv.name}</span>
                    <span className="text-[10px] text-[#9CA3AF]">{conv.time}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#9CA3AF] truncate">{conv.lastMsg}</span>
                    {conv.unread > 0 && (
                      <span className="bg-[#6C5CE7] text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full ml-2 shrink-0">{conv.unread}</span>
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </>
      ) : (
        <div className="flex-1 flex flex-col overflow-hidden bg-[#FFFDF9]">
          {/* Chat header */}
          <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5] z-20">
            <button onClick={() => setView("list")} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors">←</button>
            <div className="relative">
              <div className="w-9 h-9 rounded-full bg-[#6C5CE7] flex items-center justify-center text-white text-xs font-bold">{selectedConv.avatar}</div>
              {selectedConv.online && <div className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-[#10B981] border-2 border-white" />}
            </div>
            <div className="flex-1">
              <div className="font-display font-semibold text-[#1A1825] text-sm">{selectedConv.name}</div>
              <div className="text-[10px] text-[#10B981]">{selectedConv.online ? "Online" : "Last seen 1h ago"}</div>
            </div>
            <button className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-lg hover:bg-[#E8E2FF] transition-colors">📞</button>
            <button className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-lg hover:bg-[#E8E2FF] transition-colors">🎥</button>
          </header>

          {/* SpeakMySign in-chat banner */}
          <div className="bg-gradient-to-r from-[#6C5CE7] to-[#8B7CF8] px-4 py-2.5 flex items-center gap-3">
            <span className="text-white text-sm font-bold">🤟 SpeakMySign</span>
            <div className="flex gap-1.5 overflow-x-auto scrollbar-hide">
              {smsActions.map((a) => (
                <button
                  key={a}
                  className="shrink-0 text-[10px] bg-white/20 text-white px-2.5 py-1 rounded-full font-semibold hover:bg-white/30 transition-colors"
                >
                  {a}
                </button>
              ))}
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto scrollbar-hide px-4 py-4 space-y-3">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex items-end gap-2 ${msg.from === "me" ? "justify-end" : "justify-start"}`}
              >
                {msg.from === "them" && (
                  <div className="w-7 h-7 rounded-full bg-[#6C5CE7] flex items-center justify-center text-white text-[10px] font-bold shrink-0 mb-1">
                    {selectedConv.avatar}
                  </div>
                )}
                <div className={`max-w-[72%] relative group`}>
                  {/* SpeakMySign action button */}
                  <button
                    onClick={() => setShowSMSMenu(showSMSMenu === msg.id ? null : msg.id)}
                    className={`absolute ${msg.from === "me" ? "-left-8" : "-right-8"} top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-[#6C5CE7] text-white text-[10px] font-bold opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center z-10`}
                    title="SpeakMySign actions"
                  >
                    🤟
                  </button>

                  {showSMSMenu === msg.id && (
                    <div className={`absolute ${msg.from === "me" ? "right-0" : "left-0"} -top-24 bg-white rounded-xl shadow-xl border border-[#E8E4F5] p-1 z-20 w-36`}>
                      {smsActions.map((a) => (
                        <button
                          key={a}
                          onClick={() => setShowSMSMenu(null)}
                          className="w-full text-left text-xs px-3 py-2 text-[#1A1825] hover:bg-[#F0EEFF] rounded-lg transition-colors"
                        >
                          🤟 {a}
                        </button>
                      ))}
                    </div>
                  )}

                  {msg.type === "text" && (
                    <div className={`px-4 py-2.5 rounded-2xl text-sm ${
                      msg.from === "me"
                        ? "bg-[#6C5CE7] text-white rounded-br-sm"
                        : "bg-white border border-[#E8E4F5] text-[#1A1825] rounded-bl-sm"
                    }`}>
                      {msg.content}
                    </div>
                  )}

                  {msg.type === "voice" && (
                    <div className={`px-4 py-3 rounded-2xl flex items-center gap-3 ${
                      msg.from === "me" ? "bg-[#6C5CE7] text-white rounded-br-sm" : "bg-white border border-[#E8E4F5] text-[#1A1825] rounded-bl-sm"
                    }`}>
                      <button className="text-base">▶</button>
                      <div className="flex gap-0.5 items-center">
                        {[4,7,5,9,6,8,4,7,5,6,4].map((h, i) => (
                          <div key={i} className={`w-0.5 rounded-full ${msg.from === "me" ? "bg-white/70" : "bg-[#6C5CE7]/50"}`} style={{height:`${h}px`}} />
                        ))}
                      </div>
                      <span className="text-xs opacity-70">{msg.content.split("·")[1]?.trim()}</span>
                    </div>
                  )}

                  {msg.type === "image" && (
                    <div className="rounded-2xl overflow-hidden bg-[#F4F2FB] w-48 h-36 flex items-center justify-center border border-[#E8E4F5]">
                      <div className="text-center"><div className="text-3xl mb-1">📸</div><div className="text-xs text-[#9CA3AF]">Image</div></div>
                    </div>
                  )}

                  {msg.type === "sign-video" && (
                    <div className={`rounded-2xl overflow-hidden border ${msg.from === "me" ? "border-[#8B7CF8]" : "border-[#E8E4F5]"}`}>
                      <div className="bg-[#F0EEFF] w-48 h-32 flex items-center justify-center">
                        <div className="text-center"><div className="text-4xl mb-1">🤟</div><div className="text-xs text-[#6C5CE7] font-bold">▶ ISL Sign</div></div>
                      </div>
                      <div className={`px-3 py-1.5 text-xs font-semibold ${msg.from === "me" ? "bg-[#6C5CE7] text-white" : "bg-white text-[#6C5CE7]"}`}>
                        {msg.content}
                      </div>
                    </div>
                  )}

                  {msg.type === "sign-action" && (
                    <div className="bg-[#F0EEFF] border border-[#D8D0FF] rounded-2xl px-4 py-2.5 rounded-bl-sm">
                      <div className="text-[9px] text-[#6C5CE7] font-bold mb-0.5">🤟 {msg.signAction}</div>
                      <div className="text-sm text-[#1A1825]">{msg.content}</div>
                    </div>
                  )}

                  <div className={`text-[9px] mt-1 ${msg.from === "me" ? "text-right text-[#9CA3AF]" : "text-[#C4BBEC]"}`}>
                    {msg.time} {msg.from === "me" && "✓✓"}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Input */}
          <div className="bg-white border-t border-[#E8E4F5] px-3 py-3">
            {showAttach && (
              <div className="flex gap-3 mb-3 overflow-x-auto scrollbar-hide pb-1">
                {[["📸","Photo"],["🎬","Video"],["🤟","ISL Sign"],["🎤","Voice"],["📄","File"]].map(([e,l]) => (
                  <button key={l} onClick={() => setShowAttach(false)} className="shrink-0 flex flex-col items-center gap-1 bg-[#F0EEFF] rounded-xl px-4 py-2 hover:bg-[#E8E2FF] transition-colors">
                    <span className="text-xl">{e}</span>
                    <span className="text-[9px] text-[#6C5CE7] font-semibold">{l}</span>
                  </button>
                ))}
              </div>
            )}
            <div className="flex items-center gap-2">
              <button onClick={() => setShowAttach(!showAttach)} className="w-9 h-9 rounded-xl bg-[#F0EEFF] text-[#6C5CE7] flex items-center justify-center text-lg hover:bg-[#E8E2FF] transition-colors">+</button>
              <div className="flex-1 bg-[#F4F2FB] rounded-xl px-4 py-2.5 flex items-center gap-2">
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                  placeholder="Type a message…"
                  className="flex-1 text-sm bg-transparent outline-none text-[#1A1825] placeholder:text-[#9CA3AF]"
                />
              </div>
              {input.trim() ? (
                <button onClick={sendMessage} className="w-9 h-9 rounded-xl bg-[#6C5CE7] text-white flex items-center justify-center text-base hover:bg-[#5A4BD1] transition-colors">→</button>
              ) : (
                <button className="w-9 h-9 rounded-xl bg-[#6C5CE7] text-white flex items-center justify-center text-base hover:bg-[#5A4BD1] transition-colors">🎤</button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
