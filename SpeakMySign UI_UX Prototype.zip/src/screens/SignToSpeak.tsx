import { useState } from "react";
import type { Screen } from "../types";

type CameraState =
  | "ready"
  | "detecting"
  | "detected"
  | "low-confidence"
  | "speaking"
  | "no-hand"
  | "permission-denied"
  | "error";

interface Props {
  onNavigate: (s: Screen) => void;
}

const detectedSigns = [
  { isl: "NAMASTE", english: "Hello / Greetings", confidence: 97, emoji: "🙏" },
  { isl: "SHUKRIYA", english: "Thank You", confidence: 94, emoji: "🤝" },
  { isl: "PAANI", english: "Water", confidence: 91, emoji: "💧" },
  { isl: "MADAD", english: "Help / Assistance", confidence: 88, emoji: "🆘" },
];

const historyItems = [
  { sign: "NAMASTE", text: "Hello", time: "2m ago" },
  { sign: "SHUKRIYA", text: "Thank You", time: "5m ago" },
  { sign: "GHAR", text: "Home", time: "12m ago" },
];

export default function SignToSpeak({ onNavigate }: Props) {
  const [state, setState] = useState<CameraState>("ready");
  const [detectedIdx, setDetectedIdx] = useState(0);
  const [transcript, setTranscript] = useState<string[]>([]);

  const detected = detectedSigns[detectedIdx];

  const handleSpeak = () => {
    setState("speaking");
    setTranscript((prev) => [...prev, detected.english]);
    setTimeout(() => setState("ready"), 2200);
  };

  const cycleSign = () => {
    setDetectedIdx((i) => (i + 1) % detectedSigns.length);
    setState("detected");
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#0D0B1A]">
      {/* Header */}
      <header className="flex items-center gap-3 px-4 py-3 bg-[#0D0B1A] border-b border-white/10 z-20">
        <button onClick={() => onNavigate("home")} className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-white text-lg hover:bg-white/20 transition-colors">
          ←
        </button>
        <div className="flex-1">
          <div className="font-display font-bold text-white text-base">Sign to Speak</div>
          <div className="text-[10px] text-white/50">ISL Camera Recognition</div>
        </div>
        <button className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-base hover:bg-white/20 transition-colors">
          📋
        </button>
        <button onClick={() => onNavigate("settings")} className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-base hover:bg-white/20 transition-colors">
          ⚙️
        </button>
      </header>

      {/* State switcher pills */}
      <div className="flex gap-2 px-4 py-2 overflow-x-auto scrollbar-hide bg-[#0D0B1A]">
        {(["ready","detecting","detected","low-confidence","speaking","no-hand","permission-denied","error"] as CameraState[]).map((s) => (
          <button
            key={s}
            onClick={() => setState(s)}
            className={`shrink-0 text-[9px] font-bold px-2.5 py-1 rounded-full border transition-all ${
              state === s
                ? "bg-[#6C5CE7] border-[#6C5CE7] text-white"
                : "bg-white/5 border-white/20 text-white/50 hover:border-[#6C5CE7]/50"
            }`}
          >
            {s.replace("-"," ").toUpperCase()}
          </button>
        ))}
      </div>

      {/* Camera View */}
      <div className="relative flex-1 overflow-hidden">
        {/* Camera background simulation */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0D0B1A] via-[#1A1535] to-[#0D0B1A]">
          {state !== "permission-denied" && state !== "error" && (
            <>
              {/* Grid overlay */}
              <div className="absolute inset-0 opacity-10" style={{
                backgroundImage: "linear-gradient(rgba(108,92,231,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(108,92,231,0.5) 1px, transparent 1px)",
                backgroundSize: "40px 40px"
              }} />
              {/* Simulated hand silhouette */}
              {(state === "detecting" || state === "detected" || state === "low-confidence" || state === "speaking") && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className={`text-9xl select-none transition-all duration-500 ${
                    state === "detected" || state === "speaking" ? "opacity-90 scale-110" :
                    state === "low-confidence" ? "opacity-50 scale-90" : "opacity-70"
                  }`}>
                    🤟
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Scan line */}
        {(state === "detecting" || state === "ready") && (
          <div className="absolute left-8 right-8 h-0.5 bg-[#6C5CE7]/60 scan-line z-10 rounded-full" style={{boxShadow: "0 0 8px 2px rgba(108,92,231,0.4)"}} />
        )}

        {/* Corner guides */}
        {state !== "permission-denied" && state !== "error" && (
          <>
            {[["top-16 left-8","rounded-tl-xl border-t-2 border-l-2"],["top-16 right-8","rounded-tr-xl border-t-2 border-r-2"],["bottom-40 left-8","rounded-bl-xl border-b-2 border-l-2"],["bottom-40 right-8","rounded-br-xl border-b-2 border-r-2"]].map(([pos, cls], i) => (
              <div key={i} className={`absolute ${pos} w-8 h-8 border-[#6C5CE7] ${cls} opacity-70`} />
            ))}
          </>
        )}

        {/* State-specific overlays */}
        <div className="absolute inset-0 flex flex-col items-center justify-end pb-4 z-20">

          {/* READY */}
          {state === "ready" && (
            <div className="bg-black/60 backdrop-blur-md rounded-2xl mx-4 p-4 text-center w-full max-w-sm">
              <div className="text-white/60 text-sm mb-3">Point camera at ISL hand signs</div>
              <button onClick={() => setState("detecting")} className="bg-[#6C5CE7] text-white font-display font-bold px-6 py-3 rounded-xl text-sm hover:bg-[#5A4BD1] transition-colors w-full">
                Start Recognizing
              </button>
            </div>
          )}

          {/* DETECTING */}
          {state === "detecting" && (
            <div className="bg-black/60 backdrop-blur-md rounded-2xl mx-4 p-4 text-center w-full max-w-sm">
              <div className="flex items-center justify-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-[#6C5CE7] animate-ping" />
                <span className="text-white text-sm font-medium">Scanning for hand signs…</span>
              </div>
              <button onClick={cycleSign} className="text-[#8B7CF8] text-xs underline mt-1">
                Simulate detection →
              </button>
            </div>
          )}

          {/* NO HAND */}
          {state === "no-hand" && (
            <div className="bg-[#1A1535]/90 backdrop-blur-md rounded-2xl mx-4 p-5 text-center w-full max-w-sm border border-white/10">
              <div className="text-3xl mb-2">👋</div>
              <div className="text-white font-display font-semibold text-base mb-1">No Hand Detected</div>
              <div className="text-white/50 text-xs mb-3">Make sure your hand is clearly visible in the frame with good lighting.</div>
              <button onClick={() => setState("detecting")} className="bg-white/10 text-white text-sm px-5 py-2.5 rounded-xl hover:bg-white/20 transition-colors">
                Try Again
              </button>
            </div>
          )}

          {/* DETECTED */}
          {state === "detected" && (
            <div className="bg-[#1A1535]/95 backdrop-blur-md rounded-2xl mx-4 p-4 w-full max-w-sm border border-[#6C5CE7]/40 fade-in">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 rounded-full bg-[#00C9A7]" />
                <span className="text-[#00C9A7] text-xs font-bold">SIGN DETECTED</span>
                <span className="ml-auto text-[#6C5CE7] text-xs font-bold">{detected.confidence}% confidence</span>
              </div>
              <div className="flex items-center gap-3 mb-3">
                <div className="text-4xl">{detected.emoji}</div>
                <div>
                  <div className="font-display font-bold text-white text-xl">{detected.isl}</div>
                  <div className="text-white/60 text-sm">{detected.english}</div>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={handleSpeak} className="flex-1 bg-[#6C5CE7] text-white font-display font-bold py-3 rounded-xl text-sm hover:bg-[#5A4BD1] transition-colors flex items-center justify-center gap-2">
                  <span>🔊</span> Speak
                </button>
                <button onClick={cycleSign} className="bg-white/10 text-white px-4 rounded-xl text-sm hover:bg-white/20 transition-colors">
                  Next →
                </button>
              </div>
            </div>
          )}

          {/* LOW CONFIDENCE */}
          {state === "low-confidence" && (
            <div className="bg-[#2D1B00]/90 backdrop-blur-md rounded-2xl mx-4 p-4 w-full max-w-sm border border-[#F59E0B]/40 fade-in">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[#F59E0B] text-xs font-bold">⚠️ LOW CONFIDENCE — {detected.confidence - 30}%</span>
              </div>
              <div className="text-white/70 text-sm mb-3">Best match: <span className="text-white font-semibold">{detected.isl}</span> — but we're not sure. Please reposition your hand.</div>
              <div className="flex gap-2">
                <button onClick={() => setState("detected")} className="flex-1 bg-[#F59E0B] text-white font-bold py-2.5 rounded-xl text-sm hover:bg-[#D97706] transition-colors">
                  Accept Anyway
                </button>
                <button onClick={() => setState("detecting")} className="bg-white/10 text-white px-4 py-2.5 rounded-xl text-sm hover:bg-white/20 transition-colors">
                  Retry
                </button>
              </div>
            </div>
          )}

          {/* SPEAKING */}
          {state === "speaking" && (
            <div className="bg-[#1A1535]/95 backdrop-blur-md rounded-2xl mx-4 p-4 w-full max-w-sm border border-[#00C9A7]/40 fade-in">
              <div className="flex items-center justify-center gap-1.5 mb-2">
                {[1,2,3,4,5].map((i) => (
                  <div key={i} className="w-1.5 bg-[#00C9A7] rounded-full wave-bar" style={{height: `${12 + i * 4}px`}} />
                ))}
              </div>
              <div className="text-center">
                <div className="font-display font-bold text-white text-lg">{detected.english}</div>
                <div className="text-[#00C9A7] text-xs mt-1">Speaking…</div>
              </div>
            </div>
          )}

          {/* PERMISSION DENIED */}
          {state === "permission-denied" && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#0D0B1A]">
              <div className="text-center px-8">
                <div className="text-5xl mb-4">🚫</div>
                <div className="font-display font-bold text-white text-xl mb-2">Camera Access Denied</div>
                <div className="text-white/50 text-sm mb-6">SpeakMySign needs camera access to recognize ISL signs. Please update your permissions in Settings.</div>
                <button onClick={() => onNavigate("settings")} className="bg-[#6C5CE7] text-white font-bold px-6 py-3 rounded-xl text-sm hover:bg-[#5A4BD1] transition-colors block w-full mb-2">
                  Open Settings
                </button>
                <button onClick={() => setState("ready")} className="text-white/40 text-xs hover:text-white/60 transition-colors">
                  Use text input instead
                </button>
              </div>
            </div>
          )}

          {/* ERROR */}
          {state === "error" && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#0D0B1A]">
              <div className="text-center px-8">
                <div className="text-5xl mb-4">⚠️</div>
                <div className="font-display font-bold text-white text-xl mb-2">Camera Error</div>
                <div className="text-white/50 text-sm mb-6">Could not initialize the camera. Please check your device and try again.</div>
                <button onClick={() => setState("ready")} className="bg-[#6C5CE7] text-white font-bold px-6 py-3 rounded-xl text-sm hover:bg-[#5A4BD1] transition-colors w-full">
                  Retry
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Transcript / History */}
      <div className="bg-[#0D0B1A] border-t border-white/10 px-4 py-3 max-h-48 overflow-y-auto">
        <div className="flex items-center justify-between mb-2">
          <span className="text-white/40 text-xs font-bold tracking-wider">SESSION TRANSCRIPT</span>
          <button className="text-[#6C5CE7] text-xs">Clear</button>
        </div>
        {transcript.length === 0 ? (
          <div className="text-white/20 text-xs text-center py-2">No signs captured yet</div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {transcript.map((t, i) => (
              <span key={i} className="bg-[#6C5CE7]/20 text-[#8B7CF8] text-xs px-2.5 py-1 rounded-lg border border-[#6C5CE7]/30">
                {t}
              </span>
            ))}
          </div>
        )}
        {/* History */}
        <div className="mt-3 space-y-1">
          {historyItems.map((h, i) => (
            <div key={i} className="flex items-center gap-3 py-1.5">
              <div className="w-6 h-6 rounded-lg bg-[#6C5CE7]/20 flex items-center justify-center text-[10px] text-[#8B7CF8] font-bold shrink-0">
                🤟
              </div>
              <div className="flex-1">
                <span className="text-white/70 text-xs">{h.sign}</span>
                <span className="text-white/30 text-xs mx-1.5">→</span>
                <span className="text-white/50 text-xs">{h.text}</span>
              </div>
              <span className="text-white/20 text-[10px]">{h.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
