import { useState } from "react";
import type { Screen } from "../types";

interface Props {
  onNavigate: (s: Screen) => void;
}

const categories = ["All", "Greetings", "Family", "Numbers", "Animals", "Food", "Emotions", "Emergency", "Work"];

const signs = [
  { id: 1, isl: "NAMASTE", english: "Hello / Greetings", category: "Greetings", hand: "🙏", difficulty: "Beginner" },
  { id: 2, isl: "SHUKRIYA", english: "Thank You", category: "Greetings", hand: "🤝", difficulty: "Beginner" },
  { id: 3, isl: "PAANI", english: "Water", category: "Food", hand: "💧", difficulty: "Beginner" },
  { id: 4, isl: "MAA", english: "Mother", category: "Family", hand: "👩", difficulty: "Beginner" },
  { id: 5, isl: "BAAP", english: "Father", category: "Family", hand: "👨", difficulty: "Beginner" },
  { id: 6, isl: "KHUSH", english: "Happy", category: "Emotions", hand: "😊", difficulty: "Intermediate" },
  { id: 7, isl: "MADAD", english: "Help", category: "Emergency", hand: "🆘", difficulty: "Beginner" },
  { id: 8, isl: "ASPATAL", english: "Hospital", category: "Emergency", hand: "🏥", difficulty: "Intermediate" },
  { id: 9, isl: "EK", english: "One (1)", category: "Numbers", hand: "☝️", difficulty: "Beginner" },
  { id: 10, isl: "DO", english: "Two (2)", category: "Numbers", hand: "✌️", difficulty: "Beginner" },
  { id: 11, isl: "KHANA", english: "Food / Meal", category: "Food", hand: "🍽️", difficulty: "Beginner" },
  { id: 12, isl: "DUKHI", english: "Sad", category: "Emotions", hand: "😢", difficulty: "Intermediate" },
];

export default function Dictionary({ onNavigate }: Props) {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const [selectedSign, setSelectedSign] = useState<typeof signs[0] | null>(null);

  const filtered = signs.filter(s => {
    const matchCat = activeCategory === "All" || s.category === activeCategory;
    const matchSearch = !search || s.isl.toLowerCase().includes(search.toLowerCase()) || s.english.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  if (selectedSign) {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5]">
          <button onClick={() => setSelectedSign(null)} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors">←</button>
          <div className="flex-1">
            <div className="font-display font-bold text-[#1A1825] text-base">ISL: {selectedSign.isl}</div>
            <div className="text-[10px] text-[#9CA3AF]">{selectedSign.category} · {selectedSign.difficulty}</div>
          </div>
          <button className="bg-[#F0EEFF] text-[#6C5CE7] text-xs font-bold px-3 py-1.5 rounded-lg hover:bg-[#E8E2FF] transition-colors">
            🔖 Save
          </button>
        </header>

        <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pt-5 pb-8 space-y-5">
          {/* Sign display */}
          <div className="bg-gradient-to-br from-[#6C5CE7] to-[#8B7CF8] rounded-2xl p-8 flex flex-col items-center">
            <div className="text-8xl mb-4">{selectedSign.hand}</div>
            <div className="font-display font-bold text-white text-2xl">{selectedSign.isl}</div>
            <div className="text-white/70 text-base mt-1">{selectedSign.english}</div>
          </div>

          {/* How to sign */}
          <div className="bg-white rounded-2xl border border-[#E8E4F5] p-4">
            <div className="font-display font-semibold text-[#1A1825] mb-3">How to Sign</div>
            <ol className="space-y-2.5">
              {[
                "Position your dominant hand at chest level",
                "Form the specific handshape as shown above",
                "Move in the indicated direction smoothly",
                "Hold at the endpoint for clarity",
              ].map((step, i) => (
                <li key={i} className="flex items-start gap-3 text-sm text-[#4A4560]">
                  <span className="w-5 h-5 rounded-full bg-[#6C5CE7] text-white text-xs flex items-center justify-center shrink-0 mt-0.5 font-bold">{i+1}</span>
                  {step}
                </li>
              ))}
            </ol>
          </div>

          {/* Practice */}
          <div className="grid grid-cols-2 gap-3">
            <button className="bg-[#F0EEFF] text-[#6C5CE7] font-display font-semibold py-3.5 rounded-xl text-sm hover:bg-[#E8E2FF] transition-colors flex items-center justify-center gap-2">
              ▶ Watch Video
            </button>
            <button onClick={() => onNavigate("sign-to-speak")} className="bg-[#6C5CE7] text-white font-display font-semibold py-3.5 rounded-xl text-sm hover:bg-[#5A4BD1] transition-colors flex items-center justify-center gap-2">
              🤟 Practice
            </button>
          </div>

          {/* Related signs */}
          <div>
            <div className="font-display font-semibold text-[#1A1825] mb-3">Related Signs</div>
            <div className="grid grid-cols-3 gap-2">
              {signs.filter(s => s.category === selectedSign.category && s.id !== selectedSign.id).slice(0, 3).map((s) => (
                <button key={s.id} onClick={() => setSelectedSign(s)} className="bg-white border border-[#E8E4F5] rounded-xl p-3 text-center hover:border-[#6C5CE7]/40 transition-all">
                  <div className="text-2xl mb-1">{s.hand}</div>
                  <div className="text-[10px] font-bold text-[#6C5CE7]">{s.isl}</div>
                  <div className="text-[9px] text-[#9CA3AF]">{s.english}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-[#E8E4F5] sticky top-0 z-20">
        <button onClick={() => onNavigate("home")} className="w-9 h-9 rounded-xl bg-[#F0EEFF] flex items-center justify-center text-[#6C5CE7] text-lg hover:bg-[#E8E2FF] transition-colors">←</button>
        <div className="flex-1">
          <div className="font-display font-bold text-[#1A1825] text-base">ISL Dictionary</div>
          <div className="text-[10px] text-[#9CA3AF]">{signs.length} signs · searchable</div>
        </div>
      </header>

      <div className="px-4 py-3 bg-white border-b border-[#E8E4F5]">
        <div className="bg-[#F4F2FB] rounded-xl px-4 py-2.5 flex items-center gap-2">
          <span className="text-[#9CA3AF]">🔍</span>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search signs in English or ISL…"
            className="flex-1 text-sm bg-transparent outline-none text-[#1A1825] placeholder:text-[#9CA3AF]"
          />
          {search && <button onClick={() => setSearch("")} className="text-[#9CA3AF] text-sm">✕</button>}
        </div>
      </div>

      <div className="flex gap-2 px-4 py-3 overflow-x-auto scrollbar-hide bg-white border-b border-[#E8E4F5]">
        {categories.map((c) => (
          <button key={c} onClick={() => setActiveCategory(c)} className={`shrink-0 text-xs font-semibold px-3.5 py-2 rounded-full transition-all ${activeCategory === c ? "bg-[#6C5CE7] text-white" : "bg-[#F4F2FB] text-[#6B7280] hover:bg-[#E8E4F5]"}`}>
            {c}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pt-4 pb-24 md:pb-6">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
          {filtered.map((sign) => (
            <button
              key={sign.id}
              onClick={() => setSelectedSign(sign)}
              className="bg-white border border-[#E8E4F5] rounded-2xl p-4 text-center hover:border-[#6C5CE7]/40 hover:shadow-sm transition-all active:scale-95"
            >
              <div className="text-4xl mb-2">{sign.hand}</div>
              <div className="font-display font-bold text-[#6C5CE7] text-sm">{sign.isl}</div>
              <div className="text-[11px] text-[#6B7280] mt-0.5 leading-tight">{sign.english}</div>
              <div className="mt-2 text-[9px] bg-[#F0EEFF] text-[#6C5CE7] px-2 py-0.5 rounded-full inline-block">{sign.difficulty}</div>
            </button>
          ))}
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-12">
            <div className="text-4xl mb-3">🔍</div>
            <div className="font-display font-semibold text-[#1A1825] mb-1">No signs found</div>
            <div className="text-sm text-[#9CA3AF]">Try a different search or category</div>
          </div>
        )}
      </div>
    </div>
  );
}
