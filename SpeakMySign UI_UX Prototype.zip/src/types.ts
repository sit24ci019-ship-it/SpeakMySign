export type Screen =
  | "home"
  | "sign-to-speak"
  | "speak-to-sign"
  | "learning"
  | "dictionary"
  | "forum"
  | "forum-post"
  | "messaging"
  | "chat"
  | "sos"
  | "profile"
  | "settings"
  | "ai-tutor"
  | "quick-phrases"
  | "learning-lesson"
  | "learning-test";

export interface NavItem {
  id: string;
  label: string;
  icon: string;
  screen: Screen;
}
