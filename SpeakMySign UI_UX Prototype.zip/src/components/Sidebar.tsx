import type { Screen } from "../types";

interface Props {
  current: Screen;
  onNavigate: (s: Screen) => void;
}

const sections = [
  {
    label: "COMMUNICATION",
    items: [
      { icon: "🤟", label: "Sign to Speak", screen: "sign-to-speak" as Screen },
      { icon: "🗣️", label: "Speak to Sign", screen: "speak-to-sign" as Screen },
      { icon: "💬", label: "Quick Phrases", screen: "quick-phrases" as Screen },
    ],
  },
  {
    label: "LEARN",
    items: [
      { icon: "📚", label: "Learning Module", screen: "learning" as Screen },
      { icon: "📖", label: "ISL Dictionary", screen: "dictionary" as Screen },
      { icon: "🤖", label: "AI Sign Tutor", screen: "ai-tutor" as Screen },
    ],
  },
  {
    label: "COMMUNITY",
    items: [
      { icon: "🏛️", label: "Forum", screen: "forum" as Screen },
    ],
  },
  {
    label: "ACCOUNT",
    items: [
      { icon: "👤", label: "Profile", screen: "profile" as Screen },
      { icon: "⚙️", label: "Settings", screen: "settings" as Screen },
    ],
  },
];

export default function Sidebar({ current, onNavigate }: Props) {
  return (
    <aside className="hidden md:flex flex-col w-64 shrink-0 bg-white border-r border-[#E8E4F5] h-full overflow-y-auto">
      {/* Logo */}
      <div className="px-6 py-5 border-b border-[#E8E4F5]">
        <button onClick={() => onNavigate("home")} className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#6C5CE7] flex items-center justify-center text-lg">🤟</div>
          <div>
            <div className="font-display font-bold text-[#1A1825] text-base leading-tight">SpeakMySign</div>
            <div className="text-[10px] text-[#6B7280] font-medium tracking-widest uppercase">ISL Bridge</div>
          </div>
        </button>
      </div>

      {/* Nav sections */}
      <div className="flex-1 py-4 px-3 space-y-5">
        {sections.map((section) => (
          <div key={section.label}>
            <div className="px-3 mb-1.5 text-[9px] font-bold tracking-[0.12em] text-[#A89FD8] font-display">
              {section.label}
            </div>
            {section.items.map((item) => {
              const active = current === item.screen;
              return (
                <button
                  key={item.screen}
                  onClick={() => onNavigate(item.screen)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all mb-0.5 ${
                    active
                      ? "bg-[#F0EEFF] text-[#6C5CE7] font-semibold"
                      : "text-[#4A4560] hover:bg-[#FAF8FF] hover:text-[#6C5CE7]"
                  }`}
                >
                  <span className="text-base leading-none">{item.icon}</span>
                  <span>{item.label}</span>
                  {active && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-[#6C5CE7]" />}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* SOS button in sidebar */}
      <div className="p-4 border-t border-[#E8E4F5]">
        <button
          onClick={() => onNavigate("sos")}
          className="w-full flex items-center gap-3 px-4 py-3 bg-[#FEF2F2] text-[#DC2626] rounded-xl font-semibold text-sm hover:bg-[#FEE2E2] transition-all border border-[#FECACA]"
        >
          <span className="text-base">🚨</span>
          <span>SOS Emergency</span>
        </button>
      </div>
    </aside>
  );
}
