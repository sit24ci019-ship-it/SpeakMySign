import type { Screen } from "../types";

interface Props {
  current: Screen;
  onNavigate: (s: Screen) => void;
}

const items = [
  { icon: "🏠", label: "Home", screen: "home" as Screen },
  { icon: "🤟", label: "Sign", screen: "sign-to-speak" as Screen },
  { icon: "📚", label: "Learn", screen: "learning" as Screen },
  { icon: "💬", label: "Forum", screen: "forum" as Screen },
  { icon: "👤", label: "Profile", screen: "profile" as Screen },
];

export default function BottomNav({ current, onNavigate }: Props) {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-[#E8E4F5] safe-area-pb">
      <div className="flex items-center justify-around px-2 py-2">
        {items.map((item) => {
          const active = current === item.screen;
          return (
            <button
              key={item.screen}
              onClick={() => onNavigate(item.screen)}
              className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition-all min-w-[56px] ${
                active
                  ? "bg-[#F0EEFF] text-[#6C5CE7]"
                  : "text-[#6B7280] hover:text-[#6C5CE7]"
              }`}
            >
              <span className="text-xl leading-none">{item.icon}</span>
              <span
                className={`text-[10px] font-medium font-display tracking-wide ${
                  active ? "text-[#6C5CE7]" : "text-[#6B7280]"
                }`}
              >
                {item.label}
              </span>
              {active && (
                <div className="w-1 h-1 rounded-full bg-[#6C5CE7] mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
