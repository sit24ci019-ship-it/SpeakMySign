import { useState } from "react";
import type { Screen } from "./types";
import BottomNav from "./components/BottomNav";
import Sidebar from "./components/Sidebar";
import Home from "./screens/Home";
import SignToSpeak from "./screens/SignToSpeak";
import SpeakToSign from "./screens/SpeakToSign";
import Learning from "./screens/Learning";
import Dictionary from "./screens/Dictionary";
import Forum from "./screens/Forum";
import SOS from "./screens/SOS";
import Profile from "./screens/Profile";
import Settings from "./screens/Settings";
import AITutor from "./screens/AITutor";
import QuickPhrases from "./screens/QuickPhrases";

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");

  const navigate = (s: Screen) => setScreen(s);

  const renderScreen = () => {
    switch (screen) {
      case "home": return <Home onNavigate={navigate} />;
      case "sign-to-speak": return <SignToSpeak onNavigate={navigate} />;
      case "speak-to-sign": return <SpeakToSign onNavigate={navigate} />;
      case "learning":
      case "learning-lesson":
      case "learning-test": return <Learning onNavigate={navigate} />;
      case "dictionary": return <Dictionary onNavigate={navigate} />;
      case "forum":
      case "forum-post": return <Forum onNavigate={navigate} showPost={screen === "forum-post"} />;
      case "sos": return <SOS onNavigate={navigate} />;
      case "profile": return <Profile onNavigate={navigate} />;
      case "settings": return <Settings onNavigate={navigate} />;
      case "ai-tutor": return <AITutor onNavigate={navigate} />;
      case "quick-phrases": return <QuickPhrases onNavigate={navigate} />;
      default: return <Home onNavigate={navigate} />;
    }
  };

  return (
    <div className="h-full flex bg-[#FFFDF9]">
      {/* Desktop sidebar */}
      <Sidebar current={screen} onNavigate={navigate} />

      {/* Main content area */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        {/* Mobile: constrain width for phone-like experience on wide screens */}
        <div className="flex-1 flex flex-col md:flex-row h-full overflow-hidden">
          <div className="flex-1 flex flex-col h-full overflow-hidden max-w-full">
            {renderScreen()}
          </div>
        </div>
      </div>

      {/* Mobile bottom nav */}
      <BottomNav current={screen} onNavigate={navigate} />
    </div>
  );
}
